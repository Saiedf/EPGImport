# -*- coding: utf-8 -*-
#
# compiled by iet5
import os
import time
import glob
import shutil
from . import _, isDreamOS
from Screens.MessageBox import MessageBox
from Tools.Notifications import AddPopup
from enigma import eTimer

class EPGDeepClean(object):

    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        if isDreamOS:
            self.timer_conn = self.timer.timeout.connect(self.doClean)
        else:
            self.timer.callback.append(self.doClean)

    def start(self):
        self.session.openWithCallback(
            self.confirm,
            MessageBox,
            _("EPG DeepClean will stop Enigma2,\nclean EPG database and restart.\n\nContinue?"),
            MessageBox.TYPE_YESNO,
            timeout=15
        )

    def confirm(self, answer):
        if answer:
            AddPopup(
                _("EPG DeepClean started...\nPlease wait."),
                MessageBox.TYPE_INFO,
                5
            )
            self.timer.start(1000, True)

    def doClean(self):
        # Stop Enigma2
        os.system("init 4")
        time.sleep(3)

        # Remove EPG databases (all known locations)
        paths = [
            "/etc/enigma2/epg.db",
            "/etc/enigma2/epg.dat",
            "/media/hdd/epg.db",
            "/media/hdd/epg.dat",
            "/media/usb/epg.db",
            "/media/usb/epg.dat"
        ]

        for path in paths:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except:
                pass

        # Clean temp cache
        for pattern in ("/tmp/epg*", "/tmp/enigma2*"):
            for path in glob.glob(pattern):
                try:
                    if os.path.isdir(path):
                        shutil.rmtree(path, ignore_errors=True)
                    elif os.path.exists(path):
                        os.remove(path)
                except:
                    pass

        # Flush filesystem buffers
        os.system("sync")
        time.sleep(2)

        # Restart Enigma2
        os.system("init 3")
