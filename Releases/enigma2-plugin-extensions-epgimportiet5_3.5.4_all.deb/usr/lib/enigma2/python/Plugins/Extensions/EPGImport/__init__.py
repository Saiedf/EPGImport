# -*- coding: utf-8 -*-
# __init__.py
#
# Plugin initialization module for EPGImport
# Handles: language, layout fallback, DreamOS detection
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920 / VU+ / OpenATV / OpenSource / VTI)
#
from __future__ import absolute_import

import sys
import gettext
import re
from os import environ, path

# =========================================================
# log: shared in-memory/file-like module used by all plugin modules.
# It implements write(), getvalue() and clear(), while also mirroring
# messages to Enigma2's stdout.  Do not bind this name directly to
# sys.stdout: on OpenATV that is an EnigmaLogDebug object and it has no
# getvalue()/clear() methods, which crashes the log screen.
# =========================================================
from . import log

# =========================================================
# Python version detection flags
# =========================================================
PY3 = sys.version_info[0] >= 3
isPython312 = sys.version_info[:2] >= (3, 12)
isPython313 = sys.version_info[:2] >= (3, 13)
isPython314 = sys.version_info[:2] >= (3, 14)

# =========================================================
# Enigma2 / framework imports
# =========================================================
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop

try:
    from enigma import addFont
except ImportError:
    addFont = None

# Try to import eEnv (only available on DreamOS / some images)
try:
    from enigma import eEnv
except ImportError:
    eEnv = None

# XML parser (cElementTree is faster but deprecated in Py3.3+; fallback to ElementTree)
try:
    from xml.etree.cElementTree import parse as ET_parse
    import xml.etree.cElementTree as ET
except ImportError:
    from xml.etree.ElementTree import parse as ET_parse
    import xml.etree.ElementTree as ET

# =========================================================
# DreamOS detection
# Canonical flag used by ALL modules in this plugin.
# Aliases added for backward-compatibility with older code.
# =========================================================
def _read_image_identity():
    """Return firmware identity text without treating Dreambox hardware as DreamOS."""
    values = []
    for filename in ('/etc/image-version', '/etc/issue', '/etc/vtiversion'):
        try:
            with open(filename, 'r') as handle:
                values.append(handle.read())
        except Exception:
            pass
    return ' '.join(values).lower()


def _read_device_model():
    """Return the receiver model used to confirm genuine Dreambox hardware."""
    for filename in ('/proc/stb/info/model', '/proc/stb/info/boxtype'):
        try:
            with open(filename, 'r') as handle:
                value = handle.readline().strip().lower()
            if value:
                return value
        except Exception:
            pass
    return ''


try:
    image_identity = _read_image_identity()
    device_model = _read_device_model()
    has_opkg = (path.exists('/var/lib/opkg/status') or path.isdir('/etc/opkg') or
                path.exists('/usr/bin/opkg') or path.exists('/bin/opkg'))
    has_dpkg = (path.exists('/var/lib/dpkg/status') or path.isdir('/etc/dpkg') or
                path.exists('/usr/bin/dpkg'))
    open_source_markers = ('openatv', 'openpli', 'openbh', 'openspa', 'openhdf',
                           'openvision', 'openesi', 'vti')
    dream_sysconf_dpkg = False
    if eEnv is not None:
        try:
            dream_sysconf_dpkg = path.isdir(eEnv.resolve("${sysconfdir}/dpkg"))
        except Exception:
            pass
    dream_identity = 'dream' in image_identity
    dream_hardware = device_model.startswith('dm') or device_model.startswith('dreambox')
    # The eEnv-resolved dpkg directory is the strongest marker on DM9xx.
    # A genuine DM9xx with dpkg remains DreamOS even when a third-party feed
    # leaves opkg files behind. Explicit open-source image markers still take
    # priority so OpenATV/OpenPLi installed on Dreambox hardware use epg.dat.
    is_explicit_open_source = any(
        marker in image_identity for marker in open_source_markers
    )
    isDreamOS = bool(
        not is_explicit_open_source and (
            dream_sysconf_dpkg or
            (has_dpkg and dream_identity) or
            (has_dpkg and dream_hardware)
        )
    )
except Exception:
    isDreamOS = False

# Backward-compatibility aliases (some modules use these spellings)
isDreamos = isDreamOS
isDreamOs = isDreamOS


def connectTimer(timer, callback):
    """Connect an eTimer using the interface actually supplied by the image."""
    signal = getattr(timer, 'timeout', None)
    connector = getattr(signal, 'connect', None)
    if callable(connector):
        return connector(callback)
    callbacks = getattr(timer, 'callback', None)
    if callbacks is not None:
        if callback not in callbacks:
            callbacks.append(callback)
        return None
    # Keep the plugin running on images with an unfamiliar timer interface.
    # Some very old Enigma2 builds may have a different eTimer ABI.
    # Log the problem so it is visible in the debug log without
    # bringing down the entire plugin at import time.
    print('[EPGImport] WARNING: Unsupported eTimer interface on timer %r - callback %r not connected' % (timer, callback))
    return None


def disconnectTimer(timer, callback, connection=None):
    """Disconnect either DreamOS signal or open-source callback timers."""
    if connection is not None:
        disconnect = getattr(connection, 'disconnect', None)
        if callable(disconnect):
            try:
                disconnect()
                return
            except Exception:
                pass
    callbacks = getattr(timer, 'callback', None)
    if callbacks is not None and callback in callbacks:
        callbacks.remove(callback)

# =========================================================
# Plugin language domain (folder name = plugin name)
# =========================================================
# Use path.basename(path.dirname(...)) as the primary method
# to get the plugin's folder name (= language domain). Fall back to
# the last component of __name__ when realpath() raises on images
# with Unicode characters in their filesystem path.
try:
    PluginLanguageDomain = path.split(path.dirname(path.realpath(__file__)))[-1]
    if not PluginLanguageDomain:
        raise ValueError('empty domain from realpath')
except Exception:
    # Fallback: use the last component of the Python package name.
    # For 'Plugins.Extensions.EPGImport' this yields 'EPGImport'.
    PluginLanguageDomain = __name__.split('.')[-2] if '.' in __name__ else 'EPGImport'


def getFullPath(fname):
    """Return absolute path of a file relative to this plugin's folder."""
    return resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))


def _register_legacy_list_font():
    """Register the exact list font used by the proven version-37 UI."""
    if addFont is None:
        return
    font_path = getFullPath('skin/epgimport.ttf')
    try:
        addFont(font_path, 'EPGImport', 100, False)
        return
    except Exception:
        pass
    try:
        addFont(font_path, 'EPGImport', 100, False, 0)
    except Exception as error:
        print("[EPGImport] Could not register legacy list font: %s" % error)


_register_legacy_list_font()


def localeInit():
    """
    Initialize plugin translations.
    Sets the LANGUAGE env var and binds the .mo file path.
    Safe for both Python 2.7 and Python 3.x.
    """
    try:
        environ['LANGUAGE'] = language.getLanguage()[:2]
    except Exception:
        pass

    # Tell gettext where to find compiled .mo files.  A damaged catalog or an
    # image-specific gettext failure must never prevent the plugin from
    # starting; the translation helper will fall back to English.
    try:
        gettext.bindtextdomain(PluginLanguageDomain, getFullPath('locale'))
    except Exception as error:
        print("[EPGImport] Translation catalog unavailable; using English: %s" % error)
        return False

    # Force UTF-8 encoding for all translations (prevents mojibake on some images)
    try:
        gettext.bind_textdomain_codeset(PluginLanguageDomain, 'UTF-8')
    except Exception:
        pass

    # Activate our domain so dgettext() works correctly
    try:
        gettext.textdomain(PluginLanguageDomain)
    except Exception:
        pass
    return True


# =========================================================
# Screen resolution detection (used for skin selection)
# =========================================================
try:
    ScreenWidth = getDesktop(0).size().width()
except Exception:
    ScreenWidth = 720

# Map pixel width to the matching skin folder.
# Width categories:
#   < 1280  -> 'SD'  (old 576p/480p receivers - very rare)
#   < 1920  -> '720' (HD-Ready: 1280x720)
#  >= 1920  -> '1080' (Full-HD and above: 1920x1080, 3840x2160)
# We only ship '720' and '1080' skins, so SD falls back to '720'.
if ScreenWidth >= 1920:
    ScreenWidth = '1080'
else:
    ScreenWidth = '720'

# =========================================================
# Skin XML loading
# =========================================================
try:
    plugin_skin = ET_parse(getFullPath('skin/%s.xml' % ScreenWidth)).getroot()
except Exception as _e:
    print("[EPGImport] Error loading skin '%s': %s" % (ScreenWidth, str(_e)))
    plugin_skin = None


def isIvezSkin():
    """Return True only for the skin-ivezfb-icon family."""
    primary_skin = ''
    try:
        from Components.config import config
        primary_skin = config.skin.primary_skin.value
    except Exception:
        # A few older DreamOS builds expose the selected skin only through
        # Enigma2 settings while the plugin modules are being imported.
        try:
            with open('/etc/enigma2/settings', 'r') as settings_file:
                for setting in settings_file:
                    if setting.startswith('config.skin.primary_skin='):
                        primary_skin = setting.split('=', 1)[1].strip()
                        break
        except Exception:
            pass
    try:
        return 'skin-ivezfb-icon' in str(primary_skin).replace('\\', '/').lower()
    except Exception:
        return False


def _resolve_plugin_skin_paths(data):
    """Replace the conventional install prefix with the image-resolved path."""
    conventional = '/usr/lib/enigma2/python/Plugins/Extensions/EPGImport/'
    resolved = getFullPath('').replace('\\', '/').rstrip('/') + '/'
    try:
        return data.replace(conventional, resolved)
    except TypeError:
        return data.replace(conventional.encode('utf-8'), resolved.encode('utf-8'))


def getSkin(skinName):
    """
    Retrieve a <screen> element from the bundled skin XML as a string.
    When skin-ivezfb-icon is active, looks first for an 'Ivez'-prefixed
    screen (e.g. 'IvezEPGImportConfig') inside the same skin XML file.
    Falls back to the standard screen name for all other skins.
    Returns an empty string when not found.
    Safe for Python 2.7 and Python 3.x.
    """
    if plugin_skin is None:
        print("[EPGImport] getSkin('%s'): skin XML not loaded" % skinName)
        return ''

    # When skin-ivezfb-icon is active, prefer the Ivez-prefixed screen
    # that lives in the same XML file (e.g. IvezEPGImportConfig).
    lookup_name = skinName
    if isIvezSkin():
        ivez_name = 'Ivez' + skinName
        try:
            if plugin_skin.find('.//screen[@name="%s"]' % ivez_name) is not None:
                lookup_name = ivez_name
                print("[EPGImport] Using skin-ivezfb-icon compatibility layout for '%s'" % skinName)
        except Exception as _e:
            print("[EPGImport] Could not select skin-ivezfb-icon layout for '%s': %s" % (skinName, str(_e)))

    try:
        skin_element = plugin_skin.find('.//screen[@name="%s"]' % lookup_name)
        if skin_element is None:
            print("[EPGImport] getSkin('%s'): screen element not found in skin XML" % skinName)
            return ''
        # tostring() with encoding='unicode' returns a str in Py3;
        # with encoding='utf-8' it returns bytes in both Py2 and Py3.
        if PY3:
            # Python 3: encoding='unicode' gives str directly (no BOM)
            raw = ET.tostring(skin_element, encoding='unicode', method='xml')
        else:
            # Python 2: tostring() returns bytes (str); keep as-is
            raw = ET.tostring(skin_element, encoding='utf-8', method='xml')
            # Strip the XML declaration that ET adds when encoding is specified
            if isinstance(raw, bytes) and raw.startswith(b"<?xml"):
                raw = raw[raw.find(b'>') + 1:].lstrip()
        # The returned XML keeps the Ivez-prefixed name; rename it back to
        # the canonical screen name so Enigma2 can match it correctly.
        if lookup_name != skinName:
            try:
                raw = raw.replace(
                    'name="%s"' % lookup_name,
                    'name="%s"' % skinName,
                    1
                )
            except Exception:
                pass
        return _resolve_plugin_skin_paths(raw)
    except Exception as _e:
        print("[EPGImport] Error getting skin '%s': %s" % (skinName, str(_e)))
    return ''


# =========================================================
# Translation helper
# =========================================================
_PRINTF_TOKEN_RE = re.compile(
    r'%(?:\(([^)]+)\))?[#0\- +]*(?:\d+|\*)?(?:\.\d+|\.\*)?[hlL]?([diouxXeEfFgGcrs%])'
)


def _printf_signature(text):
    """Return placeholders used by old-style Python string formatting."""
    positional = []
    named = []
    try:
        matches = _PRINTF_TOKEN_RE.findall(text)
    except Exception:
        return None
    for name, conversion in matches:
        if conversion == '%':
            continue
        if name:
            named.append((name, conversion))
        else:
            positional.append(conversion)
    return positional, sorted(named)


def _(txt):
    """
    Translate *txt* using the plugin's own gettext domain.
    Compatible with Python 2.7 (returns bytes/str) and Python 3 (returns str).
    Always returns a safe fallback (original text) on any error.
    """
    if not txt:
        return ''

    try:
        t = gettext.dgettext(PluginLanguageDomain, txt)
    except Exception:
        return txt

    # Empty or whitespace-only msgstr entries otherwise produce invisible
    # buttons and labels.  Keep the English msgid visible instead.
    try:
        if t is None or not t.strip():
            return txt
    except Exception:
        return txt

    # Reject invalid catalog encoding before Enigma2 attempts to render it.
    try:
        if isinstance(t, bytes):
            t.decode('utf-8')
        else:
            t.encode('utf-8')
    except Exception:
        return txt

    # A translation with missing, extra, or reordered printf placeholders can
    # raise while the screen is being built.  Reject it and use English.
    source_signature = _printf_signature(txt)
    translated_signature = _printf_signature(t)
    if (source_signature is None or translated_signature is None or
            source_signature != translated_signature):
        return txt

    # Python 2: gettext may return bytes or unicode; keep consistent with
    # Enigma2 expectations. Python 3 returns Unicode text.
    return t


# =========================================================
# Activate locale and register language-change callback
# =========================================================
localeInit()
try:
    language.addCallback(localeInit)
except Exception as error:
    print("[EPGImport] Could not register language callback: %s" % error)
