#!/usr/bin/python
# -*- coding: utf-8 -*-
#
from Components.config import config
from re import sub
from sys import version_info
from xml.sax.saxutils import unescape
try:
    _basestring = basestring
    _unicode = unicode
except NameError:
    _basestring = str
    _unicode = str

try:
    from six import ensure_str
except ImportError:
    def ensure_str(s, encoding='utf-8', errors='strict'):
        if isinstance(s, _unicode) and version_info[0] < 3:
            return s.encode(encoding, errors)
        elif isinstance(s, bytes) and version_info[0] >= 3:
            return s.decode(encoding, errors)
        return s

try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

PY3 = (version_info[0] == 3)
LEFT_DOUBLE_ANGLE = u"\xab"
RIGHT_DOUBLE_ANGLE = u"\xbb"

global filterCustomChannel

# Check if epgimport configuration is defined
if hasattr(config.plugins, "epgimport") and hasattr(config.plugins.epgimport, "filter_custom_channel"):
    filterCustomChannel = config.plugins.epgimport.filter_custom_channel.value
else:
    filterCustomChannel = False  # Fallback if not defined

try:
    basestring  # Python 2
except NameError:
    basestring = str  # Python 3

def get_xml_rating_string(elem):
    """Get the rating string from XML element."""
    r = ""
    try:
        for node in elem.findall("rating"):
            for val in node.findall("value"):
                txt = val.text.replace("+", "")
                if not r:
                    r = txt
    except Exception as e:
        print("[XMLTVConverter] get_xml_rating_string error:", e)
    return ensure_str(r)

def get_xml_string(elem, name):
    """Extract the text for a given tag from XML element."""
    r = ""
    try:
        for node in elem.findall(name):
            txt = node.text
            lang = node.get("lang", None)
            if not r and txt is not None:
                r = txt
            elif lang == "nl":
                r = txt
    except Exception as e:
        print("[XMLTVConverter] get_xml_string error:", e)
    # Unescape XML entities with added characters
    r = unescape(r, entities={
        r"&apos;": r"'",
        r"&quot;": r'"',
        r"&#124;": r"|",
        r"&nbsp;": r" ",
        r"&#91;": r"[",
        r"&#93;": r"]",
    })
    return ensure_str(r)

def xml_unescape(text):
    """Clean and unescape XML text safely for both Python 2 and 3."""
    if not isinstance(text, _basestring):
        return ""
    # Ensure proper string type for Python 2/3 and DreamOS/OpenATV/VTI compatibility
    if PY3:
        # Python 3.12/3.13: ensure text is str, decode bytes if needed
        if isinstance(text, bytes):
            try:
                text = text.decode('utf-8', 'ignore')
            except:
                text = text.decode('latin-1', 'ignore')
    else:
        # Python 2.7: ensure text is utf-8 encoded bytes for processing
        if isinstance(text, _unicode):
            text = text.encode("utf-8")
    cleaned = sub(
        r"&#160;|&nbsp;|\s+",
        " ",
        unescape(
            text.strip(),
            entities={
                r"&laquo;": "«",
                r"&#171;": "«",
                r"&raquo;": "»",
                r"&#187;": "»",
                r"&apos;": r"'",
                r"&quot;": r'"',
                r"&#124;": r"|",
                r"&#91;": r"[",
                r"&#93;": r"]",
            }
        )
    )
    return cleaned.replace("Â«", LEFT_DOUBLE_ANGLE).replace("Â»", RIGHT_DOUBLE_ANGLE)

def enumerateXML(fp, tag=None):
    """
    Enumerates ElementTree nodes from file object 'fp' for a specific tag.

    Args:
        fp: File-like object containing XML data.
        tag: The XML tag to search for. If None, processes all nodes.

    Yields:
        ElementTree.Element objects matching the specified tag.
    """
    doc = iterparse(fp, events=("start", "end"))
    _, root = next(doc)  # Get the root element
    depth = 0

    for event, element in doc:
        if tag is None or element.tag == tag:  # Process all nodes if no tag is specified
            if event == "start":
                depth += 1
            elif event == "end":
                depth -= 1
                if depth == 0:  # Tag is fully parsed
                    yield element
                    element.clear()  # Free memory for the element
        elif event == "end":  # Clear other elements to free memory
            root.clear()
