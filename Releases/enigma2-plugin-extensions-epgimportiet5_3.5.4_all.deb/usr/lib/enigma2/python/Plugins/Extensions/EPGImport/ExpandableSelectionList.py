# -*- coding: utf-8 -*-
# ExpandableSelectionList.py
#
# Custom expandable list widget for EPGImport source selection screen.
# Uses skin parameters when available; falls back to hardcoded defaults.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by iet5
#

from Components.MenuList import MenuList
from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT
from Tools.LoadPixmap import LoadPixmap

from . import PluginLanguageDomain, ScreenWidth, isDreamOS
import skin


# =========================================================
# Safe icon loader — never raises, always returns None on failure.
# =========================================================
def _safe_load_pixmap(path):
    """Load a pixmap without ever raising an exception."""
    try:
        if not path:
            return None
        px = LoadPixmap(path)
        return px
    except Exception as e:
        print("[EPGImport] ExpandableSelectionList: could not load pixmap '%s': %s" % (path, e))
        return None


# =========================================================
# Icon loading for expandable/expanded categories
# Try the active skin first, fall back to bundled icons.
# =========================================================
def _load_category_icons():
    """Load expand/collapse icons with full fallback chain."""
    exp_skin = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expandable.png")
    )
    exd_skin = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expanded.png")
    )

    exp_plug = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN,
                        "Extensions/%s/icon/expandable.png" % PluginLanguageDomain)
    )
    exd_plug = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN,
                        "Extensions/%s/icon/expanded.png" % PluginLanguageDomain)
    )

    # Prefer skin; fall back to plugin bundle
    return (exp_skin or exp_plug), (exd_skin or exd_plug)


expandableIcon, expandedIcon = _load_category_icons()


# =========================================================
# Icon loading for selection checkboxes (lock_on / lock_off)
# Always load from the plugin's own bundled icons first so we
# always get proper checkbox images (☑ / ☐) rather than whatever
# lock icons the active skin may happen to have.
# Fall back to the skin only when the plugin icons are missing.
# =========================================================
def _load_checkbox_icons():
    """Load checkbox icons with plugin-first priority and full fallback chain."""
    on_plug = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN,
                        "Extensions/%s/icon/lock_on.png" % PluginLanguageDomain)
    )
    on_skin = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_on.png")
    )

    off_plug = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN,
                        "Extensions/%s/icon/lock_off.png" % PluginLanguageDomain)
    )
    off_skin = _safe_load_pixmap(
        resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_off.png")
    )

    # Plugin-bundled checkbox takes priority; skin is the fallback
    return (on_plug or on_skin), (off_plug or off_skin)


_lockOnIcon, _lockOffIcon = _load_checkbox_icons()


# =========================================================
# Safe skin-parameter helpers
# =========================================================
def get_params(*params):
    """Apply skin scaling if the helper function exists (some images provide it)."""
    try:
        if hasattr(skin, "applySkinFactor"):
            result = skin.applySkinFactor(*params)
            # Guard against applySkinFactor returning wrong length
            if result and len(result) == len(params):
                return result
    except Exception:
        pass
    return params


def _safe_int(value, default):
    """Convert *value* to int; return *default* on any error."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_skin_param(key, defaults):
    """
    Read a 4-tuple from skin.parameters.
    Returns a tuple of 4 ints guaranteed, never raises.
    """
    try:
        raw = skin.parameters.get(key, defaults)
        if raw and len(raw) >= 4:
            return (
                _safe_int(raw[0], defaults[0]),
                _safe_int(raw[1], defaults[1]),
                _safe_int(raw[2], defaults[2]),
                _safe_int(raw[3], defaults[3]),
            )
    except Exception:
        pass
    return defaults


# =========================================================
# Layout defaults (safe fallback for any skin type)
# =========================================================
_DEFAULT_CAT_DESC  = (50,  3, 700, 30)
_DEFAULT_CAT_ICON  = (10,  5,  30, 30)
_DEFAULT_ENT_DESC  = (90,  3, 620, 30)
_DEFAULT_ENT_ICON  = (50,  5,  30, 30)

# Module-level layout globals
cat_desc_loc   = _DEFAULT_CAT_DESC
cat_icon_loc   = _DEFAULT_CAT_ICON
entry_desc_loc = _DEFAULT_ENT_DESC
entry_icon_loc = _DEFAULT_ENT_ICON


def loadSettings():
    """
    Load list layout parameters from the skin (or use safe defaults).
    DreamOS uses fixed values; open-source images use skin.parameters when available.
    All values are stored as module-level globals used by category() and entry().
    Every code path is wrapped so a bad skin never causes a module-level crash.
    """
    global cat_desc_loc, entry_desc_loc, cat_icon_loc, entry_icon_loc

    try:
        if isDreamOS:
            # DreamOS: use fixed layout values (skin.parameters may not exist)
            cat_desc_loc   = (50, 3, 700, 30)
            cat_icon_loc   = (10, 5,  30, 30)
            indent         = 40   # cat_icon_loc x + w
            entry_desc_loc = (50 + indent, 3, 700 - indent, 30)
            entry_icon_loc = (10 + indent, 5, 30, 30)

        else:
            # Open Source: read layout from skin.parameters with safe helpers
            cdx, cdy, cdw, cdh = _safe_skin_param(
                "ExpandableListDescr", get_params(*_DEFAULT_CAT_DESC)
            )
            cat_desc_loc = (cdx, cdy, cdw, cdh)

            cix, ciy, ciw, cih = _safe_skin_param(
                "ExpandableListIcon", get_params(*_DEFAULT_CAT_ICON)
            )
            cat_icon_loc = (cix, ciy, ciw, cih)
            indent = _safe_int(cix, 10) + _safe_int(ciw, 30)   # x + w

            edx, edy, edw, edh = _safe_skin_param(
                "SelectionListDescr", get_params(*_DEFAULT_ENT_DESC)
            )
            entry_desc_loc = (edx + indent, edy, max(edw - indent, 100), edh)

            eix, eiy, eiw, eih = _safe_skin_param(
                "SelectionListLock", get_params(*_DEFAULT_ENT_ICON)
            )
            entry_icon_loc = (eix + indent, eiy, eiw, eih)

    except Exception as e:
        print("[EPGImport] ExpandableSelectionList.loadSettings error: %s — using defaults" % e)
        cat_desc_loc   = _DEFAULT_CAT_DESC
        cat_icon_loc   = _DEFAULT_CAT_ICON
        entry_desc_loc = _DEFAULT_ENT_DESC
        entry_icon_loc = _DEFAULT_ENT_ICON


# =========================================================
# List-entry builders
# =========================================================
def category(description, isExpanded=False):
    """Build a list entry representing a collapsible category header."""
    try:
        icon = expandedIcon if isExpanded else expandableIcon
        res = [
            (description, isExpanded, []),   # data tuple: (label, expanded_flag, children)
            (eListboxPythonMultiContent.TYPE_TEXT,) + cat_desc_loc + (0, RT_HALIGN_LEFT, description),
        ]
        # Only add the pixmap element when we actually have an icon
        if icon is not None:
            res.append(
                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)
            )
        return res
    except Exception as e:
        print("[EPGImport] category() error for '%s': %s" % (description, e))
        # Minimal safe fallback — just text, no icon
        return [
            (description, isExpanded, []),
            (eListboxPythonMultiContent.TYPE_TEXT,) + _DEFAULT_CAT_DESC + (0, RT_HALIGN_LEFT, description),
        ]


def entry(description, value, selected):
    """Build a list entry representing a selectable source item."""
    try:
        res = [
            (description, value, selected),  # data tuple
            (eListboxPythonMultiContent.TYPE_TEXT,) + entry_desc_loc + (0, RT_HALIGN_LEFT, description),
        ]
        # Use pre-loaded checkbox icons (resolved once at module load).
        # _lockOnIcon  = checked box (☑)   _lockOffIcon = empty box (☐)
        selectionpng = _lockOnIcon if selected else _lockOffIcon
        if selectionpng is not None:
            # Draw the checkbox icon at the entry icon position
            res.append(
                (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + entry_icon_loc + (selectionpng,)
            )
        else:
            # Fallback: draw a Unicode text indicator when icons are not available
            indicator = u"\u2611" if selected else u"\u2610"   # ☑ or ☐
            res.append(
                (eListboxPythonMultiContent.TYPE_TEXT,) + entry_icon_loc + (0, RT_HALIGN_LEFT, indicator)
            )
        return res
    except Exception as e:
        print("[EPGImport] entry() error for '%s': %s" % (description, e))
        # Minimal safe fallback — text only, no icon
        return [
            (description, value, selected),
            (eListboxPythonMultiContent.TYPE_TEXT,) + _DEFAULT_ENT_DESC + (0, RT_HALIGN_LEFT, description),
        ]


def expand(cat, value=True):
    """Expand or collapse a category item (toggle the icon)."""
    try:
        if not cat or not cat[0] or cat[0][1] == value:
            return
        icon = expandedIcon if value else expandableIcon
        t = cat[0]
        cat[0] = (t[0], value, t[2])
        if icon is not None:
            cat[2] = (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)
    except Exception as e:
        print("[EPGImport] expand() error: %s" % e)


def isExpanded(cat):
    """Return True when a category item is currently expanded."""
    try:
        return bool(cat[0][1])
    except Exception:
        return False


def isCategory(item):
    """Return True when the list item is a category (has a children list)."""
    try:
        return hasattr(item[0][2], "append")
    except Exception:
        return False


# =========================================================
# Widget class
# =========================================================
class ExpandableSelectionList(MenuList):
    """
    A MenuList subclass that supports expandable category headers.
    Each category can be collapsed/expanded to show/hide its child entries.
    Font is taken from the skin; setFont is NOT called directly.
    Crash-safe against any Enigma2 image / skin combination.
    """

    def __init__(self, tree=None, enableWrapAround=False):
        """
        :param tree: list of category items built with category() / entry()
        :param enableWrapAround: whether list wraps around at top/bottom
        """
        try:
            MenuList.__init__(self, [], enableWrapAround, content=eListboxPythonMultiContent)
        except Exception as e:
            print("[EPGImport] ExpandableSelectionList.__init__ MenuList error: %s" % e)
            MenuList.__init__(self, [])

        # Font size based on resolution; use the skin-registered 'EPGImport' font
        fsize       = 30 if ScreenWidth == '1080' else 24
        font_name   = "EPGImport"
        item_height = 40

        if isDreamOS:
            # DreamOS: use the bundled font directly — safe, no skin lookup needed
            pass
        else:
            # Open Source: prefer 'SelectionList' font from skin, fall back to EPGImport
            try:
                font_tuple = skin.fonts.get("SelectionList", None)
                if font_tuple and len(font_tuple) >= 1:
                    font_name   = str(font_tuple[0]) if font_tuple[0] else font_name
                    fsize       = _safe_int(font_tuple[1], fsize) if len(font_tuple) > 1 else fsize
                    item_height = _safe_int(font_tuple[2], item_height) if len(font_tuple) > 2 else item_height
            except Exception as e:
                print("[EPGImport] ExpandableSelectionList: skin.fonts error: %s — using defaults" % e)

        # Apply font and item height through the list renderer
        try:
            self.l.setFont(0, gFont(font_name, fsize))
        except Exception as e:
            print("[EPGImport] ExpandableSelectionList: setFont('%s', %s) failed: %s — trying fallback" % (font_name, fsize, e))
            try:
                self.l.setFont(0, gFont("Regular", fsize))
            except Exception as e2:
                print("[EPGImport] ExpandableSelectionList: fallback font also failed: %s" % e2)

        try:
            self.l.setItemHeight(max(20, _safe_int(item_height, 40)))
        except Exception as e:
            print("[EPGImport] ExpandableSelectionList: setItemHeight error: %s" % e)

        self.tree      = tree or []
        self.flat_list = []
        self.updateFlatList()

    def updateFlatList(self):
        """Rebuild the visible flat list from the category tree."""
        try:
            lflat = []
            for cat in self.tree:
                lflat.append(cat)
                if isExpanded(cat):
                    for item in cat[0][2]:
                        try:
                            lflat.append(entry(*item))
                        except Exception as e:
                            print("[EPGImport] updateFlatList: bad entry %r: %s" % (item, e))
            self.flat_list = lflat
            self.setList(lflat)
            self.list = lflat
        except Exception as e:
            print("[EPGImport] updateFlatList error: %s" % e)

    def _get_flat_list(self):
        """Return the current flat list safely (may be None if not yet built)."""
        try:
            flat_list = getattr(self, 'flat_list', None)
            if flat_list is None:
                flat_list = self.list if hasattr(self, 'list') else []
            return flat_list or []
        except Exception:
            return []

    def toggleSelection(self):
        """
        Toggle the current item:
        - If it is a category: expand or collapse it.
        - If it is an entry: toggle its selected state (and all entries with the same key).
        """
        try:
            idx = self.getSelectedIndex()
        except Exception:
            return

        try:
            flat_list = list(self._get_flat_list())
        except Exception:
            return

        if idx < 0 or idx >= len(flat_list):
            return

        try:
            item = flat_list[idx]
        except (IndexError, TypeError):
            return

        try:
            if isCategory(item):
                # Toggle expand / collapse
                expand(item, not item[0][1])
                self.updateFlatList()
                try:
                    self.moveToIndex(idx)
                except Exception:
                    pass
            else:
                # Toggle selection — multiple entries may share the same key (value)
                i   = item[0]
                key = i[1]
                sel = not i[2]

                # Update visible list
                for list_idx, e in enumerate(flat_list):
                    try:
                        if not isCategory(e) and e[0][1] == key:
                            flat_list[list_idx] = entry(e[0][0], key, sel)
                    except Exception:
                        pass

                # Update hidden tree data
                for cat in self.tree:
                    try:
                        for tree_idx, e in enumerate(cat[0][2]):
                            if e[1] == key and e[2] != sel:
                                cat[0][2][tree_idx] = (e[0], e[1], sel)
                    except Exception:
                        pass

                self.flat_list = flat_list
                self.setList(flat_list)
                self.list = flat_list

                try:
                    self.moveToIndex(idx)
                except Exception:
                    pass

        except Exception as e:
            print("[EPGImport] toggleSelection error at index %s: %s" % (idx, e))

    def enumSelected(self):
        """Yield all selected (description, value, True) entries from the tree."""
        try:
            for cat in self.tree:
                try:
                    for ent in cat[0][2]:
                        try:
                            if ent[2]:
                                yield ent
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception as e:
            print("[EPGImport] enumSelected error: %s" % e)


# Initialize layout parameters at module load time
loadSettings()
