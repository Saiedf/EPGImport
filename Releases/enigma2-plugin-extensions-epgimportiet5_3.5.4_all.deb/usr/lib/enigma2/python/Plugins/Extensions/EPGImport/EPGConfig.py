# -*- coding: utf-8 -*-
# EPGConfig.py
#
# Configuration, channel mapping, source enumeration, and stream handling
# for the EPGImport plugin.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920), VU+ (OpenATV/VTI), OpenSource Enigma2
#
# The code is completely modified and optimized by Dorik1972
# The code modified by iet5
#
from __future__ import print_function

import os
import sys
import glob
import subprocess
import tempfile
import time
import random
import re

try:
    from Components.config import config
except Exception:
    config = None

try:
    from enigma import eServiceCenter, eServiceReference
except Exception:
    eServiceCenter = None
    eServiceReference = None

try:
    _unicode = unicode
except NameError:
    _unicode = str

from . import log

try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

from xml.sax.saxutils import unescape
from collections import defaultdict
from shutil import copyfileobj

# Settings are tiny; use the pure-Python implementation so the restricted
# Unpickler behaves consistently on Python 2.7 and Python 3.x.
import pickle


class _RestrictedUnpickler(pickle.Unpickler):
    """Load primitive settings without permitting pickle global imports."""

    def __init__(self, *args, **kwargs):
        pickle.Unpickler.__init__(self, *args, **kwargs)
        # Python 2's cPickle uses find_global; None explicitly disables it.
        try:
            self.find_global = None
        except Exception:
            pass

    def find_class(self, module, name):
        raise pickle.UnpicklingError(
            "global objects are not allowed in EPGImport settings"
        )

# =========================================================
# Python version flags
# =========================================================
PY3      = (sys.version_info[0] == 3)
PY314    = sys.version_info[:2] >= (3, 14)
PY313    = sys.version_info[:2] >= (3, 13)
PY312    = sys.version_info[:2] >= (3, 12)

# Regex to identify absolute Windows file paths (C:\... or C:/...)
WINDOWS_ABS_PATH_RE = re.compile(r'^[A-Za-z]:[\\/]')


def _safe_import(module_name):
    try:
        module = __import__(module_name)
        return module, None
    except Exception as import_error:
        return None, import_error


zipfile, ZIPFILE_IMPORT_ERROR = _safe_import('zipfile')
gzip, GZIP_IMPORT_ERROR = _safe_import('gzip')

def _import_lzma_module():
    """Import lzma support without executing package-manager commands at runtime."""
    try:
        import lzma as native_lzma
        return native_lzma
    except ImportError:
        try:
            from backports import lzma as backports_lzma
            return backports_lzma
        except ImportError:
            return None


lzma = _import_lzma_module()

if PY3:
    from urllib.parse import urlparse
else:
    from urlparse import urlparse

# User selection stored here
SETTINGS_FILE = '/etc/epgimport/epgimport.conf'
SETTINGS_DIR = os.path.dirname(SETTINGS_FILE)
channelCache = {}
_local_service_maps_cache = {}



def _stop_duplicates_sources_enabled():
    """Return True when the plugin duplicate protection option is enabled."""
    try:
        return bool(config.plugins.epgimport.stop_duplicates_sources.value)
    except Exception:
        return False

# Cache the result so /etc/image-version and /etc/issue are opened
# only once per Enigma2 session.  The function is called from both
# _iter_bouquet_services() and getBouquetChannelList() during a single import,
# and the image type never changes at runtime.
_relaxed_bouquet_probe_cache = None


def _needs_relaxed_bouquet_probe():
    """
    On OpenATV with Python 3.14+ the bouquet reference may be flagged as
    non-directory, requiring a looser probe strategy to enumerate services.

    The result is cached at module level. The two /etc files are
    opened with a context manager (compatible with Python 2.7 and 3.14.6)
    so file handles are always closed even if an exception occurs mid-read.
    """
    global _relaxed_bouquet_probe_cache
    if _relaxed_bouquet_probe_cache is not None:
        return _relaxed_bouquet_probe_cache
    image_info = ''
    for path in ('/etc/image-version', '/etc/issue'):
        try:
            with open(path, 'r') as _f:
                image_info += _f.read()
        except Exception:
            pass
    image_info = image_info.lower()
    # Applies to Python 3.12+ on OpenATV and Python 3.14+ generally
    _relaxed_bouquet_probe_cache = (
        sys.version_info[0] == 3 and
        sys.version_info[1] >= 12 and
        ('openatv' in image_info or not image_info.strip())
    )
    return _relaxed_bouquet_probe_cache


def _decode_stderr(data):
    if not data:
        return ''
    if isinstance(data, bytes):
        try:
            return data.decode('utf-8', 'ignore')
        except Exception:
            return str(data)
    return str(data)


def _decompress_with_command(command, filename, label):
    """Run a system decompressor and return a rewound temporary stream."""
    output = tempfile.TemporaryFile()
    errors = None
    try:
        errors = tempfile.TemporaryFile()
        process = subprocess.Popen(command + [filename], stdout=output, stderr=errors)
        process.wait()
        if process.returncode != 0:
            errors.seek(0)
            raise Exception("system %s failed: %s" % (label, _decode_stderr(errors.read())))
        output.seek(0)
        return output
    except Exception:
        output.close()
        raise
    finally:
        if errors is not None:
            errors.close()


def _open_xz_stream(filename):
    """Open XZ/LZMA streams with the best available backend for the current image."""
    if lzma is not None:
        return lzma.open(filename, 'rb')

    xz_binary = '/usr/bin/xz' if os.path.exists('/usr/bin/xz') else ('/bin/xz' if os.path.exists('/bin/xz') else None)
    if xz_binary:
        return _decompress_with_command([xz_binary, '-d', '-c'], filename, 'xz')

    raise Exception("no XZ/LZMA backend available (missing xz binary and lzma module)")


def _open_gzip_stream(filename):
    if gzip is not None:
        return gzip.open(filename, 'rb')

    gzip_binary = '/bin/gzip' if os.path.exists('/bin/gzip') else ('/usr/bin/gzip' if os.path.exists('/usr/bin/gzip') else None)
    if gzip_binary:
        return _decompress_with_command([gzip_binary, '-d', '-c'], filename, 'gzip')

    raise Exception("gzip module is unavailable: %s" % repr(GZIP_IMPORT_ERROR))


def _looks_like_windows_local_path(filename):
    try:
        return bool(WINDOWS_ABS_PATH_RE.match(filename or ''))
    except Exception:
        return False


def _resolve_local_path(basepath, filename):
    if not filename:
        return filename
    try:
        filename = xml_unescape(filename)
    except Exception:
        pass

    if _looks_like_windows_local_path(filename):
        return filename

    try:
        parsed = urlparse(filename)
        scheme = (parsed.scheme or '').lower()
    except Exception:
        parsed = None
        scheme = ''

    if scheme == 'file':
        local_path = parsed.path or ''
    else:
        local_path = filename

    if not local_path:
        return local_path
    if os.path.isabs(local_path):
        return local_path

    base_dir = os.path.dirname(basepath) if basepath else ''
    if base_dir:
        return os.path.normpath(os.path.join(base_dir, local_path))
    return local_path


def _parse_source_offset(offset_value):
    try:
        text = str(offset_value or '').strip()
    except Exception:
        text = ''

    if not text:
        return 0

    sign = -1 if text.startswith('-') else 1
    text = text.lstrip('+-')
    if not text.isdigit():
        return 0

    if len(text) <= 2:
        hours = int(text)
        minutes = 0
    else:
        hours = int(text[:-2] or '0')
        minutes = int(text[-2:] or '0')

    if minutes >= 60:
        return 0
    return sign * ((hours * 60 + minutes) * 60)


def _normalize_url_list(basepath, urls):
    normalized_urls = []
    for url in urls or []:
        if isLocalFile(url):
            normalized_urls.append(_resolve_local_path(basepath, url))
        else:
            normalized_urls.append(url)
    return normalized_urls


def _normalize_service_ref_sid(ref):
    """
    Normalize SID, TSID and ONID in a service reference string.

    Enigma2 uses 16-bit integers (0x0000-0xFFFF / 0-65535) for SID,
    TSID, and ONID.  IPTV providers (e.g. Edem, some M3U-based lists)
    often assign service IDs larger than 65535 to their channels.

    When eServiceReference is constructed from such a string, Enigma2
    silently masks each of those fields to its low 16 bits:
        stored_value = raw_value & 0xFFFF

    EPGImport was storing the raw (unmasked) value, so the lookup key
    it generated never matched the key Enigma2 had stored internally -
    hence EPG data was imported but never displayed for those channels.

    This function detects when any of the three SID fields exceeds
    0xFFFF and rebuilds the reference with the masked (truncated) values
    so the key we store exactly matches what Enigma2 holds.

    The DVBnamespace field (position 6) is 32-bit and is NOT masked.

    :param ref: raw service reference string (colon-separated)
    :return:    normalised reference string (same or rebuilt)
    """
    if not ref:
        return ref
    try:
        parts = ref.split(':')
        # Need at least 7 colon-separated fields: type:flags:??:SID:TSID:ONID:DVBns:...
        if len(parts) < 7:
            return ref

        sid_hex  = parts[3]
        tsid_hex = parts[4]
        onid_hex = parts[5]

        sid_int  = int(sid_hex,  16)
        tsid_int = int(tsid_hex, 16)
        onid_int = int(onid_hex, 16)

        # Rebuild only when at least one field exceeds 16 bits.
        if sid_int > 0xFFFF or tsid_int > 0xFFFF or onid_int > 0xFFFF:
            masked_sid  = sid_int  & 0xFFFF
            masked_tsid = tsid_int & 0xFFFF
            masked_onid = onid_int & 0xFFFF

            parts[3] = '%X' % masked_sid
            parts[4] = '%X' % masked_tsid
            parts[5] = '%X' % masked_onid

            normalised = ':'.join(parts)
            print(
                "[EPGConfig][SID-NORM] ref SID truncated: "
                "sid=%s->%X tsid=%s->%X onid=%s->%X" % (
                    sid_hex, masked_sid,
                    tsid_hex, masked_tsid,
                    onid_hex, masked_onid
                ),
                file=log
            )
            return normalised
    except Exception:
        pass
    return ref


def get_ref_match_key(ref):
    """Match one physical service regardless of Enigma service type.

    The previous key included the service type (1/19/25) but omitted the DVB
    namespace.  On Dreambox that could map a DCA0000 channel-map reference to
    a DC00000 bouquet service merely because both used type 19.  Use the real
    database identity instead: SID, TSID, ONID and namespace.
    """
    if not ref:
        return None
    try:
        parts = ref.split(':')
        if len(parts) < 7:
            return None
        return ':'.join(part.upper() for part in parts[3:7])
    except Exception:
        return None


def get_service_assignment_key(ref):
    """Return one stable key for a physical DVB service assignment.

    Enigma2 can expose the same DVB service with service types 1, 19 or 25.
    Those variants are intentionally treated as one channel assignment, while
    different namespaces remain separate.  IPTV references keep their complete
    reference because their zero DVB ids do not uniquely identify a stream.
    """
    if not ref:
        return None
    try:
        parts = ref.split(':')
        if len(parts) < 7:
            return ref.strip().lower()
        dvb_parts = parts[3:7]
        if any(part.strip('0') for part in dvb_parts):
            return ':'.join(part.upper() for part in dvb_parts)
        return ref.strip().lower()
    except Exception:
        return str(ref).strip().lower()


def get_exact_service_ref_key(ref):
    """Return Enigma2 identity fields without an optional channel label."""
    if not ref:
        return None
    try:
        parts = ref.split(':')
        if len(parts) >= 10:
            return ':'.join(parts[:10]).upper()
        return ref.strip().lower()
    except Exception:
        return str(ref).strip().lower()


def is_manual_channel_assignment(ref):
    """Detect refs written by channel-assign tools with a trailing name."""
    if not ref:
        return False
    try:
        parts = ref.split(':')
        # IPTV references may contain URL delimiters after the DVB fields;
        # they are not the labelled DVB assignments handled here.
        if parts and parts[0] in ('4097', '5001', '5002', '8193'):
            return False
        return len(parts) > 11 and any(part.strip() for part in parts[11:])
    except Exception:
        return False


def normalize_channel_name(name):
    """Normalize provider and bouquet names so fallback matching is stable."""
    if not name:
        return ''
    try:
        name = xml_unescape(name)
    except Exception:
        pass
    try:
        name = name.lower()
    except Exception:
        return ''

    replacements = (
        ('osn tv', 'osn'),
        ('osntv', 'osn'),
        ('osn_', 'osn'),
        ('+', ' plus '),
        ('&', ' and '),
    )
    for old, new in replacements:
        name = name.replace(old, new)

    # Only strip truly generic words, keep hd/sd/uhd/fhd which distinguishes channels
    name = re.sub(r'\b(channel|ch)\b', ' ', name)
    name = re.sub(r'[^a-z0-9]+', '', name)
    return name.strip()


def _append_service_name_match(name_map, service_name, ref):
    normalized = normalize_channel_name(service_name)
    if normalized and ref:
        name_map[normalized].add(ref)


def _get_local_service_name(ref):
    if not ref or eServiceReference is None:
        return ''

    try:
        service_ref = eServiceReference(ref)
    except Exception:
        return ''

    try:
        service_name = service_ref.getServiceName()
    except Exception:
        service_name = ''

    if not service_name and eServiceCenter is not None:
        try:
            service_handler = eServiceCenter.getInstance()
            info = service_handler and service_handler.info(service_ref)
            if info:
                service_name = info.getName(service_ref) or ''
        except Exception:
            service_name = ''

    if service_name:
        try:
            # DVB control chars for emphasis (0x86, 0x87)
            # In Python 3, these are \x86 and \x87. In Python 2, if UTF-8 encoded, they are \xc2\x86 and \xc2\x87.
            if PY3:
                service_name = service_name.replace('\x86', '').replace('\x87', '').strip()
            else:
                service_name = service_name.replace('\xc2\x86', '').replace('\xc2\x87', '').replace('\x86', '').replace('\x87', '').strip()
        except Exception:
            pass

    return service_name or ''


def should_prefer_local_name_match(ref):
    if not ref:
        return False
    try:
        upper_ref = ref.upper()
    except Exception:
        return False
    return 'DCA0000' in upper_ref

def clear_local_service_maps_cache():
    """Discard bouquet-derived lookup maps before a new import starts."""
    global _local_service_maps_cache
    _local_service_maps_cache = {}

def _iter_bouquet_services():
    if eServiceCenter is None or eServiceReference is None:
        return

    service_handler = eServiceCenter.getInstance()
    if service_handler is None:
        return

    bouquet_roots = []
    relaxed_bouquet_probe = _needs_relaxed_bouquet_probe()
    try:
        multibouquet = bool(config and config.usage.multibouquet.value)
    except Exception:
        multibouquet = True

    if multibouquet:
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = service_handler.list(bouquet_root)
        if bouquet_list:
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                if bouquet.flags & eServiceReference.isDirectory:
                    bouquet_roots.append(bouquet)
                elif relaxed_bouquet_probe:
                    try:
                        nested_services = service_handler.list(bouquet)
                    except Exception:
                        nested_services = None
                    if nested_services:
                        bouquet_roots.append(bouquet)
        if relaxed_bouquet_probe and not bouquet_roots:
            bouquet_roots.append(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'))
    else:
        bouquet_roots.append(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'))

    mask = eServiceReference.isMarker | eServiceReference.isDirectory
    alternative_flag = eServiceReference.isGroup

    for bouquet_root in bouquet_roots:
        services_list = service_handler.list(bouquet_root)
        if not services_list:
            continue
        while True:
            service = services_list.getNext()
            if not service.valid():
                break
            if service.flags & mask:
                continue

            if service.flags & alternative_flag:
                alt_list = service_handler.list(service)
                if alt_list:
                    try:
                        for alt_ref in alt_list.getContent("S", True):
                            if alt_ref:
                                yield alt_ref
                    except Exception:
                        pass
                continue

            try:
                ref = service.toString()
            except Exception:
                ref = None
            if ref:
                yield ref

def get_local_service_maps(filterCallback=None):
    """Build both local lookup maps in one bouquet pass and cache the result."""
    try:
        cached = _local_service_maps_cache.get(filterCallback)
    except Exception:
        cached = None
    if cached is not None:
        return cached

    name_map = defaultdict(set)
    ref_map = defaultdict(set)
    scanned = 0
    accepted = 0

    try:
        for ref in _iter_bouquet_services() or []:
            scanned += 1
            try:
                if filterCallback is not None and not filterCallback(ref):
                    continue
            except Exception:
                continue

            accepted += 1
            key = get_ref_match_key(ref)
            if key:
                ref_map[key].add(ref)
            service_name = _get_local_service_name(ref)
            _append_service_name_match(name_map, service_name, ref)
        print("[EPGConfig] Local service maps built: scanned=%s accepted=%s names=%s ref_keys=%s" % (
            scanned, accepted, len(name_map), len(ref_map)
        ), file=log)
    except Exception as e:
        print("[EPGConfig] Failed to build local service maps: %s" % e, file=log)

    result = (name_map, ref_map)
    try:
        _local_service_maps_cache[filterCallback] = result
    except Exception:
        pass
    return result


def _accept_all_refs(_ref):
    return True

def isLocalFile(filename):
    """Check if a path should be handled as a local file, including relative paths."""
    if not filename:
        return False
    try:
        if _looks_like_windows_local_path(filename):
            return True
        url_parsed = urlparse(filename)
        scheme = (url_parsed.scheme or '').lower()
        return scheme in ('', 'file')
    except Exception:
        return '://' not in str(filename)

def xml_unescape(text):
    """
    :param text: The text that needs to be unescaped.
    :type text: str
    :rtype: str
    """
    if not text:
        return text
    try:
        # Python 3.4+ provides the preferred html.unescape implementation.
        if sys.version_info >= (3, 4):
            import html
            unescaped = html.unescape(text)
        elif PY3:
            # Python 3.0-3.3 (very rare on Enigma2; kept for completeness)
            # xml.sax.saxutils.unescape only handles &amp; &lt; &gt; natively;
            # pass extra entities for the common HTML ones we need.
            unescaped = unescape(text, {
                "&laquo;": u"\u00ab",
                "&#171;":  u"\u00ab",
                "&raquo;": u"\u00bb",
                "&#187;":  u"\u00bb",
                "&apos;":  u"'",
                "&nbsp;":  u" ",
                "&#160;":  u" ",
            })
        else:
            # Python 2.7 unescape() accepts native byte strings.
            _extra = {
                "&laquo;": "\xc2\xab",
                "&#171;":  "\xc2\xab",
                "&raquo;": "\xc2\xbb",
                "&#187;":  "\xc2\xbb",
                "&apos;":  "'",
                "&nbsp;":  " ",
                "&#160;":  " ",
            }
            # Work on UTF-8 bytes string (which is what Py2 str is in practice here)
            _txt = text.encode('utf-8') if isinstance(text, _unicode) else text
            unescaped = unescape(_txt, _extra)

        # Remove non-breaking-space entities and collapse whitespace
        return re.sub(r'&#160;|&nbsp;|\s+', ' ', unescaped.strip())
    except Exception as e:
        print("[EPGConfig] xml_unescape error:", e, file=log)
        return text if text else ''

def ensure_settings_directory():
    try:
        if SETTINGS_DIR and not os.path.isdir(SETTINGS_DIR):
            os.makedirs(SETTINGS_DIR)
    except OSError:
        if not os.path.isdir(SETTINGS_DIR):
            raise


def getChannels(path, name=None, *unused_args):
    """Retrieve cached channels or load new EPGChannel"""
    if name in channelCache:
        return channelCache[name]
    dirname, filename = os.path.split(path)
    if name:
        channelfile = _resolve_local_path(path, name) if isLocalFile(name) else name
    else:
        channelfile = os.path.join(dirname, filename.split('.', 1)[0] + '.channels.xml')
    try:
        return channelCache[channelfile]
    except KeyError:
        channelCache[channelfile] = EPGChannel(channelfile, basepath=path)
        return channelCache[channelfile]

def getFiletype(fp):
    """Detect the type of a file by reading its signature"""
    if hasattr(fp, 'seek'):
        bs = fp.read(64)
        fp.seek(0, 0)
    else:
        with open(fp, "rb") as f:
            bs = f.read(64)

    if bs[:2] == b"\x1f\x8b":
        return "GZ"
    elif bs[:6] == b"\xfd\x37\x7a\x58\x5a\x00":
        return "XZ"
    elif bs[:4] == b"\x50\x4b\x03\x04":
        return "ZIP"
    elif bs[:6] == b"\x3c\x3f\x78\x6d\x6c\x20":
        return "XML"
    elif bs[:9] == b"\xef\xbb\xbf\x3c\x3f\x78\x6d\x6c\x20":
        return "XML"  # utf-8-bom
    try:
        normalized = bs.lstrip(b"\xef\xbb\xbf\r\n\t ")
    except Exception:
        normalized = bs
    if normalized.startswith(b'<?xml') or normalized.startswith(b'<'):
        return "XML"
    return None

def openStream(filename):
    """Open a file stream with automatic decompression based on file type"""
    try:
        file_size = os.path.getsize(filename)
    except OSError as e:
        raise Exception("[EPGConfig] Cannot access file: %s (%s)" % (filename, e))

    if not file_size:
        raise Exception("[EPGConfig] %s file is empty" % filename)

    ftype = getFiletype(filename)
    fd = None
    try:
        if ftype == 'GZ':
            fd = _open_gzip_stream(filename)
        elif ftype == 'XZ':
            fd = _open_xz_stream(filename)
        elif ftype == 'ZIP':
            if zipfile is None:
                raise Exception("zipfile module is unavailable: %s" % repr(ZIPFILE_IMPORT_ERROR))
            zip_obj = zipfile.ZipFile(filename, 'r')
            fd = tempfile.TemporaryFile()
            try:
                members = [name for name in zip_obj.namelist() if not name.endswith('/')]
                if not members:
                    raise Exception("ZIP archive contains no files")
                source = zip_obj.open(members[0])
                try:
                    copyfileobj(source, fd, 1024 * 1024)
                finally:
                    source.close()
                fd.seek(0)
            finally:
                zip_obj.close()
        elif ftype == 'XML':
            fd = open(filename, 'rb')
        else:
            raise KeyError(ftype)
    except KeyError:
        raise Exception("unsupported file type: %s" % ftype)
    except Exception as e:
        if fd is not None:
            try:
                fd.close()
            except Exception:
                pass
        raise Exception("file %s is not a valid %s: %s" % (filename, ftype, str(e)))

    if ftype != 'XML' and getFiletype(fd) != 'XML':
        try:
            fd.close()
        except Exception:
            pass
        raise Exception("[EPGConfig] %s file is not a valid XML" % filename)
    else:
        return fd

def enumerateXML(fp, tag=None):
    """Enumerates ElementTree nodes from file object 'fp'"""
    doc = iterparse(fp, events=('start', 'end'))
    _, root = next(doc)
    depth = 0
    for event, element in doc:
        if element.tag == tag:
            if event == 'start':
                depth += 1
            else:
                depth -= 1
                if depth == 0:
                    yield element
                    element.clear()
        if event == 'end' and element.tag != tag:
            root.clear()

class EPGChannel(object):
    """Representation of a channel lookup table"""
    def __init__(self, filename, urls=None, basepath=None):
        self.mtime = None
        self.custom_mtime = None
        self.custom_loaded = False
        self.name = filename
        self.basepath = basepath or filename
        raw_urls = [filename] if urls is None else urls
        self.urls = _normalize_url_list(self.basepath, raw_urls)
        self.items = defaultdict(set)
        # A physical service may belong to one XMLTV channel id only inside a
        # single assignment file.  The registry is reset for every parsed file
        # because custom.channels.xml and a provider's downloaded channel file
        # can legitimately use different XMLTV ids for the same service.
        self._assigned_service_ids = {}
        self._assigned_exact_refs = {}
        self._strict_assignment_file = False

    def _add_channel_assignment(self, channel_id, ref):
        """Reject a repeated manual assignment, but retain provider aliases."""
        assignment_key = get_service_assignment_key(ref)
        if assignment_key is None:
            return False, None
        assigned = getattr(self, '_assigned_service_ids', None)
        if assigned is None:
            assigned = {}
            self._assigned_service_ids = assigned
        exact_assigned = getattr(self, '_assigned_exact_refs', None)
        if exact_assigned is None:
            exact_assigned = {}
            self._assigned_exact_refs = exact_assigned
        exact_key = get_exact_service_ref_key(ref)
        exact_owner = exact_assigned.get(exact_key)
        if self._strict_assignment_file and exact_owner is not None and exact_owner != channel_id:
            return False, exact_owner
        owner = assigned.get(assignment_key)
        if owner is not None and owner != channel_id:
            # Provider channel tables (including elcinema) legitimately map
            # more than one XMLTV id to one service because the ids may carry
            # complementary schedules.  Keep those aliases so the DreamOS
            # backend can retain the longer union.  A labelled ref appended by
            # an Assign screen is a user assignment and must not claim an
            # already assigned physical service for a second id.
            if self._strict_assignment_file and is_manual_channel_assignment(ref):
                return False, owner
            self.items[channel_id].add(ref)
            exact_assigned[exact_key] = channel_id
            return True, owner
        assigned[assignment_key] = channel_id
        exact_assigned[exact_key] = channel_id
        self.items[channel_id].add(ref)
        return True, owner

    def parse(self, filterCallback, downloadedFile):
        """Parse *****_channels.xml lookup table file"""
        print("[EPGConfig] Enumerating channels lookup table XML file: %s" % downloadedFile, file=log)
        if self.items is None:
            self.items = defaultdict(set)
        # Enforce "assigned once" within this file only.  Carrying ownership
        # over from the global custom file rejected the correct ids in remote
        # provider maps (for example Cartoon Network HD and CNN HD).
        self._assigned_service_ids = {}
        self._assigned_exact_refs = {}
        try:
            parsed_basename = os.path.basename(str(downloadedFile)).lower()
        except Exception:
            parsed_basename = ''
        # The user's local OSN assignment tables are editable and must reject
        # a second assignment.  Other provider tables such as elcinema contain
        # intentional aliases whose schedules must be merged, not discarded.
        self._strict_assignment_file = parsed_basename in (
            'osnar.channels.xml',
            'osnen.channels.xml',
        )
        count = 0
        accepted_count = 0
        dca0000_count = 0
        fallback_count = 0
        fallback_miss_count = 0
        override_count = 0
        ref_override_count = 0
        duplicate_assignment_count = 0
        debug_limit = 12
        duplicate_assignment_log_count = [0]

        def add_assignment(channel_id, service_ref):
            added, owner = self._add_channel_assignment(channel_id, service_ref)
            if not added and owner is not None and duplicate_assignment_log_count[0] < debug_limit:
                print("[EPGConfig][ASSIGNMENT-REJECTED] ref=%s already_assigned_to=%s rejected_id=%s" % (
                    service_ref, owner, channel_id
                ), file=log)
                duplicate_assignment_log_count[0] += 1
            return added

        # -------------------------------------------------------
        # Build the local service maps ONCE before the loop.
        # Previously these were built lazily *inside* the loop
        # (initialised on the first channel), which caused a freeze
        # on images with > 10 000 IPTV channels because the heavy
        # bouquet scan was triggered mid-iteration on the main thread.
        # -------------------------------------------------------
        local_name_map, local_ref_map = get_local_service_maps(filterCallback)

        stream = None
        try:
            stream = openStream(downloadedFile)
            for elem in enumerateXML(stream, 'channel'):
                count += 1
                id_val = elem.get('id')
                ref = elem.text
                if id_val and ref:
                    id_val = xml_unescape(id_val.lower())
                    ref = xml_unescape(ref)

                    # ---------------------------------------------------
                    # Normalize SID, TSID and ONID.
                    #
                    # Enigma2 stores SID/TSID/ONID as 16-bit values
                    # (max 65535).  IPTV providers (e.g. Edem) often use
                    # IDs > 65535.  When eServiceReference is constructed
                    # from such a string, Enigma2 silently masks each
                    # field to its low 16 bits, so the stored key differs
                    # from the raw string and EPG never matches.
                    #
                    # We detect this by checking if any of the SID/TSID/
                    # ONID fields (hex, colon-separated positions 3-5)
                    # exceeds 0xFFFF and, if so, rebuild the ref string
                    # with the masked values before storing it.
                    # ---------------------------------------------------
                    ref = _normalize_service_ref_sid(ref)

                    accepted = False
                    try:
                        accepted = bool(filterCallback(ref))
                    except Exception as e:
                        print("[EPGConfig][CHANNEL] filterCallback error id=%s ref=%s err=%s" % (id_val, ref, e), file=log)

                    normalized_id = normalize_channel_name(id_val)
                    local_refs = local_name_map.get(normalized_id, set()) if normalized_id else set()
                    source_ref_key = get_ref_match_key(ref)
                    local_ref_overrides = local_ref_map.get(source_ref_key, set()) if source_ref_key else set()

                    if accepted and local_ref_overrides and should_prefer_local_name_match(ref):
                        for local_ref in local_ref_overrides:
                            if add_assignment(id_val, local_ref):
                                ref_override_count += 1
                            else:
                                duplicate_assignment_count += 1
                        if ref_override_count <= debug_limit:
                            print("[EPGConfig][REF-OVERRIDE] id=%s source_ref=%s local_refs=%s" % (id_val, ref, list(local_ref_overrides)[:4]), file=log)
                    elif accepted and local_refs and should_prefer_local_name_match(ref):
                        for local_ref in local_refs:
                            if add_assignment(id_val, local_ref):
                                override_count += 1
                            else:
                                duplicate_assignment_count += 1
                        if override_count <= debug_limit:
                            print("[EPGConfig][NAME-OVERRIDE] id=%s normalized=%s source_ref=%s local_refs=%s" % (id_val, normalized_id, ref, list(local_refs)[:4]), file=log)
                    elif accepted:
                        if add_assignment(id_val, ref):
                            accepted_count += 1
                            if 'DCA0000' in ref.upper():
                                dca0000_count += 1
                        else:
                            duplicate_assignment_count += 1
                    elif local_ref_overrides:
                        for local_ref in local_ref_overrides:
                            if add_assignment(id_val, local_ref):
                                ref_override_count += 1
                            else:
                                duplicate_assignment_count += 1
                        if ref_override_count <= debug_limit:
                            print("[EPGConfig][REF-FALLBACK] id=%s source_ref=%s local_refs=%s" % (id_val, ref, list(local_ref_overrides)[:4]), file=log)
                    elif local_refs:
                        for fallback_ref in local_refs:
                            if add_assignment(id_val, fallback_ref):
                                fallback_count += 1
                            else:
                                duplicate_assignment_count += 1
                        if fallback_count <= debug_limit:
                            print("[EPGConfig][NAME-FALLBACK] id=%s normalized=%s source_ref=%s matched_refs=%s" % (id_val, normalized_id, ref, list(local_refs)[:4]), file=log)
                    else:
                        fallback_miss_count += 1
                        if fallback_miss_count <= debug_limit:
                            print("[EPGConfig][NAME-FALLBACK-MISS] id=%s normalized=%s source_ref=%s" % (id_val, normalized_id, ref), file=log)
                    if count <= debug_limit:
                        print("[EPGConfig][CHANNEL] #%d id=%s ref=%s accepted=%s" % (count, id_val, ref, accepted), file=log)

            print("[EPGConfig] Processed: %s channels" % count, file=log)
            print("[EPGConfig] Accepted refs: %s, DCA0000 refs: %s, Ref override refs: %s, Name override refs: %s, Name fallback refs: %s, Duplicate assignments rejected: %s, Fallback misses: %s" % (accepted_count, dca0000_count, ref_override_count, override_count, fallback_count, duplicate_assignment_count, fallback_miss_count), file=log)
        except Exception as e:
            print("[EPGConfig] failed to parse", self.name, "Error:", e, file=log)
        else:
            print("[EPGConfig] Formed lookup table for: %s channels id" % len(self.items), file=log)
        finally:
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass

    def update(self, filterCallback, downloadedFile=None):
        custom_file = '/etc/epgimport/custom.channels.xml'
        # Keep the current lookup table while importing additional channel files
        # for the same source so mappings are merged instead of losing earlier ones.
        if os.path.exists(custom_file) and not self.custom_loaded:
            self.parse(_accept_all_refs, custom_file)
            try:
                self.custom_mtime = os.path.getmtime(custom_file)
            except Exception:
                self.custom_mtime = None
            self.custom_loaded = True
        else:
            if not os.path.exists(custom_file):
                self.custom_mtime = None
                self.custom_loaded = False
        if downloadedFile is not None:
            self.mtime = time.time()
            return self.parse(filterCallback, downloadedFile)
        elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
            self.parse(filterCallback, self.urls[0])
            try:
                self.mtime = os.path.getmtime(self.urls[0])
            except Exception:
                self.mtime = None

    def downloadables(self):
        if not (len(self.urls) == 1 and isLocalFile(self.urls[0])):
            return self.urls
        return []

    def __repr__(self):
        return "EPGChannel(urls=%s, channels=%s, mtime=%s)" % (self.urls, len(self.items) if self.items else 0, self.mtime)

class EPGSource(object):
    """Representation of a source"""
    def __init__(self, path, elem, category=None, offset=0):
        self.parser = elem.get('type', 'gen_xmltv')
        self.nocheck = int(elem.get('nocheck', 0))
        self.urls = _normalize_url_list(path, [xml_unescape(e.text) for e in elem.findall('url') if e.text and e.text.strip()])
        # Let the importer skip source entries without a usable URL.
        self.url = random.choice(self.urls) if self.urls else ''
        self.description = xml_unescape(elem.findtext('description', self.url))
        self.category = category
        self.offset = offset
        self.format = elem.get('format', 'xml')
        self.channels = getChannels(path, elem.get('channels'))

def enumSourcesFile(sourcefile, filter=None, categories=False):
    """Parse /etc/epgimport/*.sources.xml|.gz|.xz|.zip"""
    category = None
    stream = None
    try:
        stream = openStream(sourcefile)
        for event, elem in iterparse(stream, events=("start", "end")):
            if event == 'end':
                if elem.tag == 'source':
                    s = EPGSource(sourcefile, elem, category, _parse_source_offset(elem.get('offset', '+0000')))
                    elem.clear()
                    # Skip malformed sources without a usable URL.
                    if not s.url:
                        print("[EPGConfig] Skipping source with no URL: %s" % s.description, file=log)
                        continue
                    if (filter is None) or (s.description in filter):
                        yield s
                elif elem.tag == 'channel':
                    name = xml_unescape(elem.get('name'))
                    urls = _normalize_url_list(sourcefile, [xml_unescape(e.text) for e in elem.findall('url')])
                    try:
                        channelCache[name].urls = urls
                    except Exception:
                        channelCache[name] = EPGChannel(name, urls, sourcefile)
                elif elem.tag == 'sourcecat':
                    category = None
            elif event == 'start':
                # Need the category name sooner than the contents, hence "start"
                if elem.tag == 'sourcecat':
                    category = xml_unescape(elem.get('sourcecatname'))
                    if categories:
                        yield category
    except Exception as e:
        print("[EPGConfig] enumSourcesFile Error:", e, file=log)
    finally:
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass

def enumSources(path, filter=None, categories=False):
    """Enumerate all source files in a path.

    When Stop Duplicates Sources is enabled from the plugin setup, source entries
    with the same description are yielded only once. This prevents Rytec source
    duplicates from appearing after updating/installing sources while preserving
    the original behaviour when the option is disabled.
    """
    supported_suffixes = (
        '.sources.xml',
        '.sources.xml.gz',
        '.sources.xml.xz',
        '.sources.xml.zip',
        '.sources.xml.lzma',
    )
    seen_sources = set()
    stop_duplicates_sources = _stop_duplicates_sources_enabled()
    try:
        for file in glob.iglob(os.path.join(path, '*.sources.*')):
            lower_file = file.lower()
            if not lower_file.endswith(supported_suffixes):
                print("[EPGConfig] Skipping unsupported sources file: %s" % file, file=log)
                continue
            for s in enumSourcesFile(file, filter, categories):
                if stop_duplicates_sources and hasattr(s, 'description'):
                    desc_key = (s.description or '').strip().lower()
                    
                    # Only apply aggressive description-based deduplication to Rytec sources.
                    # This prevents skipping legitimate custom/IPTV sources (like OSN) 
                    # that share the same description but provide different language events.
                    if 'rytec' in desc_key:
                        key = desc_key
                    else:
                        url_key = ''
                        try:
                            if hasattr(s, 'url') and s.url:
                                url_key = str(s.url).strip().lower()
                            elif hasattr(s, 'urls') and s.urls:
                                url_key = str(s.urls[0]).strip().lower()
                        except Exception:
                            pass
                        key = desc_key + '|' + url_key if url_key else desc_key + '|' + str(id(s))

                    if key in seen_sources:
                        print("[EPGConfig] Skipping duplicate source: %s" % s.description, file=log)
                        continue
                    seen_sources.add(key)
                yield s
    except Exception as e:
        print("[EPGConfig] enumSources Error:", e, file=log)

def loadUserSettings(filename=SETTINGS_FILE):
    """Load user settings from pickle file"""
    try:
        if not os.path.exists(filename):
            return {"sources": []}
        with open(filename, 'rb') as handle:
            settings = _RestrictedUnpickler(handle).load()
        if not isinstance(settings, dict) or not isinstance(settings.get("sources"), list):
            raise ValueError("invalid settings structure")
        return settings
    except Exception as e:
        print("[EPGConfig] No settings", e, file=log)
        return {"sources": []}

def storeUserSettings(filename=SETTINGS_FILE, sources=None):
    """Store user settings atomically so interruption cannot truncate them."""
    if sources is None:
        sources = []
    container = {"sources": sources}
    ensure_settings_directory()
    temporary = filename + '.epgimport-writing'
    try:
        with open(temporary, 'wb') as handle:
            pickle.dump(container, handle, pickle.HIGHEST_PROTOCOL)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        replace = getattr(os, 'replace', os.rename)
        replace(temporary, filename)
    except Exception:
        try:
            if os.path.exists(temporary):
                os.unlink(temporary)
        except Exception:
            pass
        raise

# Export the required functions for other modules
__all__ = ['xml_unescape', 'enumerateXML', 'loadUserSettings', 'storeUserSettings',
           'enumSources', 'EPGChannel', 'EPGSource', 'channelCache',
           'clear_local_service_maps_cache']
