# -*- coding: utf-8 -*-
from __future__ import print_function
#
# The code modified by iet5
#
import traceback
from os.path import join
import tempfile
from enigma import eEnv
from . import isDreamOS, log
from .EPGImport import bigStorage

if isDreamOS:
    from . import epgdb
    from Components.config import config
else:
    from . import epgdat

# Media paths to search for storage
medialist = ['/media/hdd', '/media/usb', '/media/mmc', '/media/cf', '/media/sdcard']
# Temporary path with sufficient space
tmppath = bigStorage(9000000, tempfile.gettempdir(), *medialist)
settingspath = eEnv.resolve("${sysconfdir}/enigma2/")

class epgdatclass(object):
    """Class to handle EPG database interactions"""

    def __init__(self):
        self.data = None
        self.services = None

        if isDreamOS:
            self.epgfile = config.misc.epgcache_filename.value
            self.epg = epgdb.epgdb_class(
                "EPGImport", 99, self.epgfile, config.plugins.epgimport.clear_oldepg.value
            )
        else:
            self.epgfile = join(tmppath, 'epg_new.dat')
            self.epg = epgdat.epgdat_class(tmppath, settingspath, self.epgfile)

        print("[EPGImport] EPG database located at %s" % self.epgfile, file=log)

    def importEvents(self, services, dataTupleList):
        """Add events to EPG; called repeatedly"""
        if services != self.services:
            self.commitService()
            self.services = services

        event_count = 0
        for program in dataTupleList:
            program = list(program)
            # Combine title and subtitle if needed
            program[3] = '\n'.join(program[3:5]) if program[3] else program[4]
            program = program[:4] + program[-1:] if isDreamOS else program[:4]
            try:
                self.epg.add_event(*program)
                event_count += 1
            except Exception as e:
                print("[EPGImport] Error adding event: %s" % str(e), file=log)

        if event_count > 0:
            print("[EPGImport] Added %d events to queue for service: %s" % (event_count, str(services)), file=log)

    def commitService(self):
        """Commit events for the current service"""
        if self.services is not None:
            try:
                self.epg.preprocess_events_channel(self.services)
                print("[EPGImport] commitService completed for service: %s" % str(self.services), file=log)
            except Exception as e:
                print("[EPGImport] Error in commitService: %s" % str(e), file=log)
                import traceback
                traceback.print_exc(file=log)
                raise

    def epg_done(self):
        """Finalize all EPG data and close the database"""
        try:
            print("[EPGImport] Starting epg_done, committing final service...", file=log)
            self.commitService()
            print("[EPGImport] Finalizing EPG database...", file=log)
            self.epg.final_process()
            print("[EPGImport] epg_done completed successfully", file=log)
        except Exception as e:
            print("[EPGImport] Failure in epg_done: %s" % str(e), file=log)
            traceback.print_exc(file=log)
        finally:
            self.epg = None

    def __del__(self):
        """Destructor - finalize the file when done"""
        if self.epg is not None:
            self.epg_done()
