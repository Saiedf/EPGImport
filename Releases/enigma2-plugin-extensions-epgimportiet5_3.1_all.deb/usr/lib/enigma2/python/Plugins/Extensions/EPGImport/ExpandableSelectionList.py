# -*- coding: utf-8 -*-
#
# The code modified by iet5
#

from Components.MenuList import MenuList
from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, eEnv
from Tools.LoadPixmap import LoadPixmap
from . import PluginLanguageDomain, ScreenWidth, isDreamOS, isDreamos, isDreamOs, PY3, isPython312, isPython313
import skin

# Load icons for expandable and expanded categories
expandableIcon = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expandable.png"))
expandedIcon = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expanded.png"))
if not (expandableIcon or expandedIcon):
    expandableIcon = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/%s/icon/expandable.png" % PluginLanguageDomain))
    expandedIcon = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/%s/icon/expanded.png" % PluginLanguageDomain))


def get_params(*params):
    if hasattr(skin, "applySkinFactor"):
        return skin.applySkinFactor(*params)
    return params


def loadSettings():
    global cat_desc_loc, entry_desc_loc, cat_icon_loc, entry_icon_loc
    try:
        # expandable list (skin parameters defined by the plugin)
        x, y, w, h = skin.parameters.get("ExpandableListDescr", get_params(50, 3, 700, 30)) if not isDreamOS else (50, 3, 700, 30)
        cat_desc_loc = (x, y, w, h)
        x, y, w, h = skin.parameters.get("ExpandableListIcon", get_params(10, 5, 30, 30)) if not isDreamOS else (10, 5, 30, 30)
        cat_icon_loc = (x, y, w, h)

        indent = x + w  # indentation for the selection list entries

        # selection list (skin parameters also used in enigma2)
        x, y, w, h = skin.parameters.get("SelectionListDescr", get_params(50, 3, 700, 30)) if not isDreamOS else (50, 3, 700, 30)
        entry_desc_loc = (x + indent, y, w - indent, h)
        x, y, w, h = skin.parameters.get("SelectionListLock", get_params(10, 5, 30, 30)) if not isDreamOS else (10, 5, 30, 30)
        entry_icon_loc = (x + indent, y, w, h)
    except Exception:
        cat_desc_loc = (50, 3, 700, 30)
        cat_icon_loc = (10, 5, 30, 30)
        entry_desc_loc = (90, 3, 620, 30)
        entry_icon_loc = (50, 5, 30, 30)


def category(description, isExpanded=False):
    icon = expandedIcon if isExpanded else expandableIcon
    return [
        (description, isExpanded, []),
        (eListboxPythonMultiContent.TYPE_TEXT,) + cat_desc_loc + (0, RT_HALIGN_LEFT, description),
        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)]


def entry(description, value, selected):
    res = [
        (description, value, selected),
        (eListboxPythonMultiContent.TYPE_TEXT,) + entry_desc_loc + (0, RT_HALIGN_LEFT, description)
    ]
    selectionpng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_%s.png" % ("on" if selected else "off")))
    if selectionpng:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + entry_icon_loc + (selectionpng,))
    return res


def expand(cat, value=True):
    # cat is a list of data and icons
    if cat[0][1] != value:
        icon = expandedIcon if value else expandableIcon
        t = cat[0]
        cat[0] = (t[0], value, t[2])
        cat[2] = (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)


def isExpanded(cat):
    return cat[0][1]


def isCategory(item):
    # Return whether list entry is a Category
    return hasattr(item[0][2], "append")


class ExpandableSelectionList(MenuList):
    def __init__(self, tree=None, enableWrapAround=False):
        'tree is expected to be a list of categories'
        MenuList.__init__(self, [], enableWrapAround, content=eListboxPythonMultiContent)
        fsize = 30 if ScreenWidth == '1080' else 24
        font = ("EPGImport", fsize, 40) if isDreamOS else skin.fonts.get("SelectionList", get_params("EPGImport", fsize, 40))
        self.l.setFont(0, gFont(font[0], font[1]))
        self.l.setItemHeight(font[2])
        self.tree = tree or []
        self.flat_list = []
        self.updateFlatList()

    def updateFlatList(self):
        # Update the view of the items by flattening the tree
        lflat = []
        for cat in self.tree:
            lflat.append(cat)
            if isExpanded(cat):
                for item in cat[0][2]:
                    lflat.append(entry(*item))
        self.flat_list = lflat
        self.setList(lflat)
        self.list = lflat

    def _get_flat_list(self):
        flat_list = getattr(self, 'flat_list', None)
        if flat_list is None:
            flat_list = self.list if hasattr(self, 'list') else []
        return flat_list or []

    def toggleSelection(self):
        idx = self.getSelectedIndex()
        flat_list = list(self._get_flat_list())
        if idx < 0 or idx >= len(flat_list):
            return
        item = flat_list[idx]
        # Only toggle selections, not expandables...
        if isCategory(item):
            expand(item, not item[0][1])
            self.updateFlatList()
            try:
                self.moveToIndex(idx)
            except Exception:
                pass
        else:
            # Multiple items may have the same key. Toggle them all,
            # in both the visual list and the hidden items
            i = item[0]
            key = i[1]
            sel = not i[2]
            for list_idx, e in enumerate(flat_list):
                if not isCategory(e) and e[0][1] == key:
                    flat_list[list_idx] = entry(e[0][0], key, sel)
            for cat in self.tree:
                for tree_idx, e in enumerate(cat[0][2]):
                    if e[1] == key and e[2] != sel:
                        cat[0][2][tree_idx] = (e[0], e[1], sel)
            self.flat_list = flat_list
            self.setList(flat_list)
            self.list = flat_list
            try:
                self.moveToIndex(idx)
            except Exception:
                pass

    def enumSelected(self):
        for cat in self.tree:
            for entry in cat[0][2]:
                if entry[2]:
                    yield entry


loadSettings()
