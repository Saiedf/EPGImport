# -*- coding: utf-8 -*-

from __future__ import print_function
# The code is completely modified and optimized by Dorik1972
# The code modified by iet5
#
import os

def _diag_isdreamos():
    try:
        return os.path.exists('/usr/bin/apt') or os.path.exists('/usr/bin/apt-get') or os.path.exists('/var/lib/dpkg/status')
    except Exception:
        return False

isDreamOS = _diag_isdreamos()
import sys
import glob
import zipfile
import gzip
import subprocess
import time
import random
import re
try:
    from Components.config import config
except Exception:
    config = None

try:
    from enigma import eServiceCenter, eServiceReference
except Exception:
    eServiceCenter = None
    eServiceReference = None

try:
    _unicode = unicode
except NameError:
    _unicode = str

from . import log

try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

from xml.sax.saxutils import unescape
from collections import defaultdict

try:
    import cPickle as pickle
except ImportError:
    import pickle

PY3 = (sys.version_info[0] == 3)

def _import_lzma_module():
    """Import lzma support without executing package-manager commands at runtime."""
    try:
        import lzma as native_lzma
        return native_lzma
    except ImportError:
        try:
            from backports import lzma as backports_lzma
            return backports_lzma
        except ImportError:
            return None


lzma = _import_lzma_module()

if PY3:
    from urllib.parse import urlparse
    from io import BytesIO
else:
    from urlparse import urlparse
    from StringIO import StringIO as BytesIO

# User selection stored here
SETTINGS_FILE = '/etc/epgimport/epgimport.conf'
channelCache = {}


def _decode_stderr(data):
    if not data:
        return ''
    if isinstance(data, bytes):
        try:
            return data.decode('utf-8', 'ignore')
        except Exception:
            return str(data)
    return str(data)


def _open_xz_stream(filename):
    """Open XZ/LZMA streams with the best available backend for the current image."""
    xz_binary = '/usr/bin/xz' if os.path.exists('/usr/bin/xz') else ('/bin/xz' if os.path.exists('/bin/xz') else None)
    if xz_binary:
        process = subprocess.Popen(
            [xz_binary, '-d', '-c', filename],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        out, err = process.communicate()
        if process.returncode == 0:
            return BytesIO(out)
        print("[EPGConfig] System xz failed for %s: %s" % (filename, _decode_stderr(err)), file=log)

    if lzma is not None:
        with lzma.open(filename, 'rb') as compressed:
            return BytesIO(compressed.read())

    raise Exception("no XZ/LZMA backend available (missing xz binary and lzma module)")

def get_ref_match_key(ref):
    if not ref:
        return None
    try:
        parts = ref.split(':')
        if len(parts) < 7:
            return None
        return ':'.join(parts[:6])
    except Exception:
        return None


def normalize_channel_name(name):
    """Normalize provider and bouquet names so fallback matching is stable."""
    if not name:
        return ''
    try:
        name = xml_unescape(name)
    except Exception:
        pass
    try:
        name = name.lower()
    except Exception:
        return ''

    replacements = (
        ('osn tv', 'osn'),
        ('osntv', 'osn'),
        ('osn_', 'osn'),
        ('+', ' plus '),
        ('&', ' and '),
    )
    for old, new in replacements:
        name = name.replace(old, new)

    name = re.sub(r'\b(hd|sd|uhd|fhd|tv|channel|ch)\b', ' ', name)
    name = re.sub(r'[^a-z0-9]+', '', name)
    return name.strip()

def _append_service_name_match(name_map, service_name, ref):
    normalized = normalize_channel_name(service_name)
    if normalized and ref:
        name_map[normalized].add(ref)

def should_prefer_local_name_match(ref):
    if not ref:
        return False
    try:
        upper_ref = ref.upper()
    except Exception:
        return False
    return 'DCA0000' in upper_ref

def get_local_service_ref_map(filterCallback=None):
    ref_map = defaultdict(set)
    scanned = 0
    accepted = 0
    try:
        for ref in _iter_bouquet_services() or []:
            scanned += 1
            try:
                if filterCallback is not None and not filterCallback(ref):
                    continue
            except Exception:
                continue
            accepted += 1
            key = get_ref_match_key(ref)
            if key:
                ref_map[key].add(ref)
        print("[EPGConfig] Local service-ref override map built: scanned=%s accepted=%s keys=%s" % (scanned, accepted, len(ref_map)), file=log)
    except Exception as e:
        print("[EPGConfig] Failed to build local service-ref override map: %s" % e, file=log)
    return ref_map

def _iter_bouquet_services():
    if eServiceCenter is None or eServiceReference is None:
        return

    service_handler = eServiceCenter.getInstance()
    if service_handler is None:
        return

    bouquet_roots = []
    try:
        multibouquet = bool(config and config.usage.multibouquet.value)
    except Exception:
        multibouquet = True

    if multibouquet:
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = service_handler.list(bouquet_root)
        if bouquet_list:
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                if bouquet.flags & eServiceReference.isDirectory:
                    bouquet_roots.append(bouquet)
    else:
        bouquet_roots.append(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet'))

    mask = eServiceReference.isMarker | eServiceReference.isDirectory
    alternative_flag = eServiceReference.isGroup

    for bouquet_root in bouquet_roots:
        services_list = service_handler.list(bouquet_root)
        if not services_list:
            continue
        while True:
            service = services_list.getNext()
            if not service.valid():
                break
            if service.flags & mask:
                continue

            if service.flags & alternative_flag:
                alt_list = service_handler.list(service)
                if alt_list:
                    try:
                        for alt_ref in alt_list.getContent("S", True):
                            if alt_ref:
                                yield alt_ref
                    except Exception:
                        pass
                continue

            try:
                ref = service.toString()
            except Exception:
                ref = None
            if ref:
                yield ref

def get_local_service_name_map(filterCallback=None):
    name_map = defaultdict(set)
    scanned = 0
    accepted = 0

    try:
        for ref in _iter_bouquet_services() or []:
            scanned += 1
            try:
                if filterCallback is not None and not filterCallback(ref):
                    continue
            except Exception:
                continue

            accepted += 1
            try:
                service_name = eServiceReference(ref).getServiceName()
            except Exception:
                service_name = ''

            _append_service_name_match(name_map, service_name, ref)
        print("[EPGConfig] Local service-name fallback map built: scanned=%s accepted=%s names=%s" % (scanned, accepted, len(name_map)), file=log)
    except Exception as e:
        print("[EPGConfig] Failed to build local service-name fallback map: %s" % e, file=log)
    return name_map

def isLocalFile(filename):
    """Check if the file exists locally"""
    url_parsed = urlparse(filename)
    if url_parsed.scheme in ('file', ''):  # Possibly a local file
        return os.path.exists(url_parsed.path)
    return False

def xml_unescape(text):
    """
    :param text: The text that needs to be unescaped.
    :type text: str
    :rtype: str
    """
    if not text:
        return text
    try:
        # Ensure text is proper string type for Python 2.7 and 3.12/3.13
        if PY3 and isinstance(text, bytes):
            try:
                text = text.decode('utf-8', 'ignore')
            except:
                text = text.decode('latin-1', 'ignore')
        elif not PY3 and isinstance(text, str):
            # Python 2: ensure unicode for processing
            try:
                text = text.decode('utf-8', 'ignore')
            except:
                pass
        # Python 3.4+ has html.unescape
        if sys.version_info >= (3, 4):
            import html
            unescaped = html.unescape(text)
        else:
            # For older Python versions including Python 2.7
            if PY3:
                unescaped = unescape(text, {
                    "&laquo;": "«",
                    "&#171;": "«",
                    "&raquo;": "»",
                    "&#187;": "»",
                    "&apos;": "'",
                })
            else:
                unescaped = unescape(text.encode('utf-8').strip() if isinstance(text, _unicode) else text.strip(), {
                    "&laquo;": "«",
                    "&#171;": "«",
                    "&raquo;": "»",
                    "&#187;": "»",
                    "&apos;": "'",
                })

        # Clean up whitespace and special characters
        return re.sub(r'&#160;|&nbsp;|\s+', ' ', unescaped.strip())
    except Exception as e:
        print("[EPGConfig] xml_unescape error:", e, file=log)
        return text if text else ''

def getChannels(path, name=None):
    """Retrieve cached channels or load new EPGChannel"""
    if name in channelCache:
        return channelCache[name]
    dirname, filename = os.path.split(path)
    if name:
        channelfile = os.path.join(dirname, name) if isLocalFile(name) else name
    else:
        channelfile = os.path.join(dirname, filename.split('.', 1)[0] + '.channels.xml')
    try:
        return channelCache[channelfile]
    except KeyError:
        channelCache[channelfile] = EPGChannel(channelfile)
        return channelCache[channelfile]

def getFiletype(fp):
    """Detect the type of a file by reading its signature"""
    if hasattr(fp, 'seek'):
        bs = fp.read(10)
        fp.seek(0, 0)
    else:
        with open(fp, "rb") as f:
            bs = f.read(10)

    if bs[:2] == b"\x1f\x8b":
        return "GZ"
    elif bs[:6] == b"\xfd\x37\x7a\x58\x5a\x00":
        return "XZ"
    elif bs[:4] == b"\x50\x4b\x03\x04":
        return "ZIP"
    elif bs[:6] == b"\x3c\x3f\x78\x6d\x6c\x20":
        return "XML"
    elif bs[:9] == b"\xef\xbb\xbf\x3c\x3f\x78\x6d\x6c\x20":
        return "XML"  # utf-8-bom
    return None

def openStream(filename):
    """Open a file stream with automatic decompression based on file type"""
    try:
        if not os.path.getsize(filename):
            raise Exception("[EPGConfig] %s file is empty" % filename)
    except Exception as e:
        print('error: ', str(e))
        raise Exception("[EPGConfig] Unexpected error occurred with file: %s" % filename)

    ftype = getFiletype(filename)
    try:
        if ftype == 'GZ':
            fd = gzip.open(filename, 'rb')
        elif ftype == 'XZ':
            fd = _open_xz_stream(filename)
        elif ftype == 'ZIP':
            zip_obj = zipfile.ZipFile(filename, 'r')
            try:
                fd = BytesIO(zip_obj.open(zip_obj.namelist()[0]).read())
            finally:
                zip_obj.close()
        elif ftype == 'XML':
            fd = open(filename, 'rb')
        else:
            raise KeyError(ftype)
    except KeyError:
        raise Exception("unsupported file type: %s" % ftype)
    except Exception as e:
        raise Exception("file %s is not a valid %s: %s" % (filename, ftype, str(e)))

    if ftype != 'XML' and getFiletype(fd) != 'XML':
        raise Exception("[EPGConfig] %s file is not a valid XML" % filename)
    else:
        return fd

def enumerateXML(fp, tag=None):
    """Enumerates ElementTree nodes from file object 'fp'"""
    doc = iterparse(fp, events=('start', 'end'))
    _, root = next(doc)
    depth = 0
    for event, element in doc:
        if element.tag == tag:
            if event == 'start':
                depth += 1
            else:
                depth -= 1
                if depth == 0:
                    yield element
                    element.clear()
        if event == 'end' and element.tag != tag:
            root.clear()

class EPGChannel(object):
    """Representation of a channel lookup table"""
    def __init__(self, filename, urls=None):
        self.mtime = None
        self.name = filename
        self.urls = [filename] if urls is None else urls
        self.items = defaultdict(set)

    def parse(self, filterCallback, downloadedFile):
        """Parse *****_channels.xml lookup table file"""
        print("[EPGConfig] Enumerating channels lookup table XML file", file=log)
        self.items = defaultdict(set)  # set make the reference unique to avoid loading twice the same EPG data.
        count = 0
        accepted_count = 0
        dca0000_count = 0
        fallback_count = 0
        fallback_miss_count = 0
        override_count = 0
        ref_override_count = 0
        debug_limit = 12
        local_name_map = None
        local_ref_map = None
        try:
            for elem in enumerateXML(openStream(downloadedFile), 'channel'):
                count += 1
                id_val = elem.get('id')
                ref = elem.text
                if id_val and ref:
                    id_val = xml_unescape(id_val.lower())
                    ref = xml_unescape(ref)
                    accepted = False
                    try:
                        accepted = bool(filterCallback(ref))
                    except Exception as e:
                        print("[EPGConfig][CHANNEL] filterCallback error id=%s ref=%s err=%s" % (id_val, ref, e), file=log)
                    if local_name_map is None:
                        local_name_map = get_local_service_name_map(filterCallback)
                    if local_ref_map is None:
                        local_ref_map = get_local_service_ref_map(filterCallback)

                    normalized_id = normalize_channel_name(id_val)
                    local_refs = local_name_map.get(normalized_id, set()) if normalized_id else set()
                    source_ref_key = get_ref_match_key(ref)
                    local_ref_overrides = local_ref_map.get(source_ref_key, set()) if source_ref_key else set()

                    if accepted and local_ref_overrides and should_prefer_local_name_match(ref):
                        for local_ref in local_ref_overrides:
                            self.items[id_val].add(local_ref)
                        ref_override_count += len(local_ref_overrides)
                        if ref_override_count <= debug_limit:
                            print("[EPGConfig][REF-OVERRIDE] id=%s source_ref=%s local_refs=%s" % (id_val, ref, list(local_ref_overrides)[:4]), file=log)
                    elif accepted and local_refs and should_prefer_local_name_match(ref):
                        for local_ref in local_refs:
                            self.items[id_val].add(local_ref)
                        override_count += len(local_refs)
                        if override_count <= debug_limit:
                            print("[EPGConfig][NAME-OVERRIDE] id=%s normalized=%s source_ref=%s local_refs=%s" % (id_val, normalized_id, ref, list(local_refs)[:4]), file=log)
                    elif accepted:
                        self.items[id_val].add(ref)
                        accepted_count += 1
                        if 'DCA0000' in ref.upper():
                            dca0000_count += 1
                    else:
                        if local_refs:
                            for fallback_ref in local_refs:
                                self.items[id_val].add(fallback_ref)
                            fallback_count += len(local_refs)
                            if fallback_count <= debug_limit:
                                print("[EPGConfig][NAME-FALLBACK] id=%s normalized=%s source_ref=%s matched_refs=%s" % (id_val, normalized_id, ref, list(local_refs)[:4]), file=log)
                        else:
                            fallback_miss_count += 1
                            if fallback_miss_count <= debug_limit:
                                print("[EPGConfig][NAME-FALLBACK-MISS] id=%s normalized=%s source_ref=%s" % (id_val, normalized_id, ref), file=log)
                    if count <= debug_limit:
                        print("[EPGConfig][CHANNEL] #%d id=%s ref=%s accepted=%s" % (count, id_val, ref, accepted), file=log)

            print("[EPGConfig] Processed: %s channels" % count, file=log)
            print("[EPGConfig] Accepted refs: %s, DCA0000 refs: %s, Ref override refs: %s, Name override refs: %s, Name fallback refs: %s, Fallback misses: %s" % (accepted_count, dca0000_count, ref_override_count, override_count, fallback_count, fallback_miss_count), file=log)
        except Exception as e:
            print("[EPGConfig] failed to parse", self.name, "Error:", e, file=log)
        else:
            print("[EPGConfig] Formed lookup table for: %s channels id" % len(self.items), file=log)

    def update(self, filterCallback, downloadedFile=None):
        if downloadedFile is not None:
            self.mtime = time.time()
            return self.parse(filterCallback, downloadedFile)
        elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
            mtime = os.path.getmtime(self.urls[0])
            if (not self.mtime) or (self.mtime < mtime):
                self.parse(filterCallback, self.urls[0])
                self.mtime = mtime

    def downloadables(self):
        if not (len(self.urls) == 1 and isLocalFile(self.urls[0])):
            # Check at most once a day
            # now = time.time()
            if (not self.mtime) or (time.time() - self.mtime <= 86400):
                return self.urls
        return []

    def __repr__(self):
        return "EPGChannel(urls=%s, channels=%s, mtime=%s)" % (self.urls, len(self.items) if self.items else 0, self.mtime)

class EPGSource(object):
    """Representation of a source"""
    def __init__(self, path, elem, category=None):
        self.parser = elem.get('type', 'gen_xmltv')
        self.nocheck = int(elem.get('nocheck', 0))
        self.urls = [xml_unescape(e.text) for e in elem.findall('url')]
        self.url = random.choice(self.urls)
        self.description = xml_unescape(elem.findtext('description', self.url))
        self.category = category
        self.format = elem.get('format', 'xml')
        self.channels = getChannels(path, elem.get('channels'))

def enumSourcesFile(sourcefile, filter=None, categories=False):
    """Parse /etc/epgimport/*.sources.xml|.gz|.xz|.zip"""
    category = None
    try:
        for event, elem in iterparse(openStream(sourcefile), events=("start", "end")):
            if event == 'end':
                if elem.tag == 'source':
                    s = EPGSource(sourcefile, elem, category)
                    elem.clear()
                    if (filter is None) or (s.description in filter):
                        yield s
                elif elem.tag == 'channel':
                    name = xml_unescape(elem.get('name'))
                    urls = [xml_unescape(e.text) for e in elem.findall('url')]
                    try:
                        channelCache[name].urls = urls
                    except:
                        channelCache[name] = EPGChannel(name, urls)
                elif elem.tag == 'sourcecat':
                    category = None
            elif event == 'start':
                # Need the category name sooner than the contents, hence "start"
                if elem.tag == 'sourcecat':
                    category = xml_unescape(elem.get('sourcecatname'))
                    if categories:
                        yield category
    except Exception as e:
        print("[EPGConfig] enumSourcesFile Error:", e, file=log)

def enumSources(path, filter=None, categories=False):
    """Enumerate all source files in a path"""
    try:
        for file in glob.iglob(os.path.join(path, '*.sources.*')):
            for s in enumSourcesFile(file, filter, categories):
                yield s
    except Exception as e:
        print("[EPGConfig] enumSources Error:", e, file=log)

def loadUserSettings(filename=SETTINGS_FILE):
    """Load user settings from pickle file"""
    try:
        with open(filename, 'rb') as handle:
            # Python 2.7 and Python 3.12/3.13 compatibility
            if PY3:
                try:
                    return pickle.load(handle, encoding='latin1')
                except TypeError:
                    # Older pickle without encoding parameter
                    handle.seek(0)
                    return pickle.load(handle)
            else:
                return pickle.load(handle)
    except Exception as e:
        print("[EPGConfig] No settings", e, file=log)
        return {"sources": []}

def storeUserSettings(filename=SETTINGS_FILE, sources=[]):
    """Store user settings into pickle file"""
    container = {"sources": sources}
    with open(filename, 'wb') as handle:
        pickle.dump(container, handle, pickle.HIGHEST_PROTOCOL)

# Export the required functions for other modules
__all__ = ['xml_unescape', 'enumerateXML', 'loadUserSettings', 'storeUserSettings',
           'enumSources', 'EPGChannel', 'EPGSource', 'channelCache']
