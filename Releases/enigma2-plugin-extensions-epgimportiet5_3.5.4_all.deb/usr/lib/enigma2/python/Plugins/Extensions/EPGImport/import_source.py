#!/usr/bin/python
# -*- coding: utf-8 -*-
# import_source.py
#
# Downloads and installs EPGImport source files from a remote GitHub tarball.
# Handles safe extraction (path-traversal protection) and destination cleanup.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
from __future__ import print_function

import os
import ssl
import tarfile
from os import listdir, makedirs, remove, walk
from os.path import join, isdir, exists
from shutil import rmtree, copytree, copy2

try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse


MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 20000
MAX_EXTRACTED_BYTES = 512 * 1024 * 1024


# =========================================================
# Directory creation helper (Python 2 / 3 safe)
# =========================================================
def make_dirs(directory):
    """Create *directory* and all parents; silently ignore if it already exists."""
    try:
        makedirs(directory)
    except OSError:
        if not isdir(directory):
            raise


# =========================================================
# URL open helper (Python 2 / 3 compatible)
# =========================================================
try:
    import urllib.request as urllib_request   # Python 3

    def url_open(url, context, timeout=60):
        """Open *url* with an SSL *context* (Python 3)."""
        if context is not None:
            return urllib_request.urlopen(url, context=context, timeout=timeout)
        return urllib_request.urlopen(url, timeout=timeout)

except ImportError:
    import urllib2 as urllib_request          # Python 2

    def url_open(url, context, timeout=60):  # noqa: F811
        """Open *url* on Python 2, using an SSL context when supported."""
        try:
            return urllib_request.urlopen(url, context=context, timeout=timeout)
        except TypeError:
            return urllib_request.urlopen(url, timeout=timeout)


# =========================================================
# Directory tree copy helper (Python 2 / 3 safe)
# =========================================================
def copytree_compat(src, dst):
    """
    Copy a directory tree from *src* to *dst*.
    Removes *dst* first if it already exists (copytree requires a non-existent target).
    """
    if exists(dst):
        rmtree(dst, ignore_errors=True)
    copytree(src, dst)


# =========================================================
# Safe tarball extraction (prevents path-traversal attacks)
# =========================================================
def _is_within_directory(directory, target):
    """
    Return True only when *target* is fully inside *directory*.
    Protects against 'zip-slip' / path-traversal attacks.
    """
    base_dir   = os.path.abspath(directory)
    target_path = os.path.abspath(target)
    return target_path == base_dir or target_path.startswith(base_dir + os.sep)


def safe_extract_tar(tar, destination):
    """
    Extract all members of *tar* into *destination*, raising TarError if
    any member path escapes the destination directory.
    """
    members = tar.getmembers()
    if len(members) > MAX_ARCHIVE_MEMBERS:
        raise tarfile.TarError("Source archive contains too many entries")

    extracted_size = 0
    for member in members:
        member_target = os.path.join(destination, member.name)
        if not _is_within_directory(destination, member_target):
            raise tarfile.TarError(
                "Unsafe path in tar archive (path traversal attempt): %s" % member.name
            )
        if member.issym() or member.islnk() or member.isdev():
            raise tarfile.TarError(
                "Unsupported link or device entry in tar archive: %s" % member.name
            )
        if member.isfile():
            extracted_size += max(0, member.size)
            if extracted_size > MAX_EXTRACTED_BYTES:
                raise tarfile.TarError("Source archive is too large after extraction")
        if member.mode & 0o7000:
            raise tarfile.TarError(
                "Unsafe permission bits in tar archive: %s" % member.name
            )
    tar.extractall(path=destination, members=members)


# =========================================================
# SSL context helper (Python 2.7 / 3.x safe)
# =========================================================
def get_verified_context():
    """
    Return the platform's certificate-verifying SSL context.

    On older Python 2 images without ``create_default_context``, returning
    ``None`` deliberately leaves verification to urllib's secure default.  We
    never fall back to CERT_NONE because source archives become executable
    plugin configuration after installation.
    """
    # Primary: Python 2.7.9+ and all Python 3.x versions
    try:
        return ssl.create_default_context()
    except AttributeError:
        return None


def copy_response_limited(response, output):
    """Copy a response while preventing an archive from filling storage."""
    total = 0
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk:
            return total
        total += len(chunk)
        if total > MAX_ARCHIVE_BYTES:
            raise ValueError("Downloaded source archive exceeds the size limit")
        output.write(chunk)


def recover_interrupted_update(destination, backup):
    """Restore a known-good backup left by an interrupted directory swap."""
    if not exists(backup):
        return False
    if not exists(destination):
        os.rename(backup, destination)
        return True
    if isdir(destination) and isdir(backup):
        try:
            destination_empty = not listdir(destination)
            backup_has_files = bool(listdir(backup))
        except OSError:
            return False
        if destination_empty and backup_has_files:
            rmtree(destination)
            os.rename(backup, destination)
            return True
    return False


# =========================================================
# Main installation function
# =========================================================
def main(url):
    """
    Download the EPG sources tarball from *url*, extract it, and install
    the source files to /etc/epgimport.

    Steps:
      1. Create working directories
      2. Download the tarball over verified HTTPS
      3. Safe-extract the tarball
      4. Remove unwanted .bb build recipe files
      5. Copy source files to /etc/epgimport
      6. Remove the old epgimport.conf so the plugin reloads sources
      7. Sync filesystem
    """
    TMPSources   = "/var/volatile/tmp/EPGimport-Sources-main"
    dest_dir     = "/etc/epgimport"
    staging_dir  = dest_dir + ".epgimport-new"
    backup_dir   = dest_dir + ".epgimport-backup"
    SETTINGS_FILE = "/etc/enigma2/epgimport.conf"
    tarball      = join(TMPSources, "main.tar.gz")

    parsed_url = urlparse(url)
    if parsed_url.scheme.lower() != 'https' or not parsed_url.hostname:
        raise ValueError("EPG source updates require a valid HTTPS URL")

    # Recover the last known-good directory if a previous update stopped after
    # moving it aside but before activating the staged replacement.
    recover_interrupted_update(dest_dir, backup_dir)

    # Start from a clean staging area so stale files from an interrupted update
    # can never be installed as part of the new source package.
    if exists(TMPSources):
        rmtree(TMPSources, ignore_errors=True)

    # Ensure both directories exist
    make_dirs(TMPSources)
    make_dirs(dest_dir)

    context = get_verified_context()

    # Download the tarball from the remote URL
    response = None
    try:
        response = url_open(url, context, timeout=60)
        final_url = response.geturl() if hasattr(response, 'geturl') else url
        if urlparse(final_url).scheme.lower() != 'https':
            raise ValueError("EPG source update redirected to an insecure URL")
        with open(tarball, "wb") as out_file:
            copy_response_limited(response, out_file)
    except Exception:
        rmtree(TMPSources, ignore_errors=True)
        raise
    finally:
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    # Extract the tarball safely (path-traversal protected)
    try:
        with tarfile.open(tarball, "r:gz") as tar:
            safe_extract_tar(tar, TMPSources)
    except tarfile.TarError as _e:
        rmtree(TMPSources, ignore_errors=True)
        raise Exception("Error extracting source archive: %s" % _e)

    extracted_dir = join(TMPSources, "EPGimport-Sources-main")
    if not isdir(extracted_dir):
        rmtree(TMPSources, ignore_errors=True)
        raise Exception("Downloaded source archive has an unexpected structure")

    # Remove .bb OpenEmbedded build recipe files (not needed on target device)
    for root, _dirs, files in walk(extracted_dir):
        for fname in files:
            if fname.endswith(".bb"):
                try:
                    remove(join(root, fname))
                except Exception:
                    pass

    # Build a complete replacement beside the destination, then swap it in.
    if exists(staging_dir):
        rmtree(staging_dir, ignore_errors=True)
    make_dirs(staging_dir)
    try:
        for item in listdir(extracted_dir):
            src_item = join(extracted_dir, item)
            if isdir(src_item):
                copytree_compat(src_item, join(staging_dir, item))
            else:
                copy2(src_item, staging_dir)

        # The ignore list is user data and must survive source updates.
        ignore_file = join(dest_dir, 'ignore.conf')
        if exists(ignore_file):
            copy2(ignore_file, staging_dir)
    except Exception:
        rmtree(staging_dir, ignore_errors=True)
        rmtree(TMPSources, ignore_errors=True)
        raise

    if exists(backup_dir):
        rmtree(backup_dir, ignore_errors=True)
        if exists(backup_dir):
            rmtree(staging_dir, ignore_errors=True)
            rmtree(TMPSources, ignore_errors=True)
            raise OSError("Could not remove stale EPG source backup")
    backup_moved = False
    try:
        if exists(dest_dir):
            os.rename(dest_dir, backup_dir)
            backup_moved = True
        os.rename(staging_dir, dest_dir)
    except Exception:
        if backup_moved and exists(backup_dir) and not exists(dest_dir):
            os.rename(backup_dir, dest_dir)
        rmtree(staging_dir, ignore_errors=True)
        rmtree(TMPSources, ignore_errors=True)
        raise
    rmtree(backup_dir, ignore_errors=True)

    # Clean up the temporary extraction directory
    rmtree(TMPSources, ignore_errors=True)

    # Remove the old settings file so the plugin reloads and picks up new sources
    if exists(SETTINGS_FILE):
        try:
            remove(SETTINGS_FILE)
        except Exception as _e:
            print("[import_source] Could not remove settings file: %s" % _e)

    # Flush all filesystem buffers to storage (os.sync available on Python 3.3+)
    try:
        from os import sync as _sync
        _sync()
    except ImportError:
        # Python 2.7 and some older builds don't have os.sync; ignore
        pass

    print("[import_source] Sources installed successfully to %s" % dest_dir)
    return True


# Example usage (for testing outside the plugin):
# if __name__ == "__main__":
#     url = "https://github.com/Belfagor2005/EPGimport-Sources/archive/refs/heads/main.tar.gz"
#     main(url)
