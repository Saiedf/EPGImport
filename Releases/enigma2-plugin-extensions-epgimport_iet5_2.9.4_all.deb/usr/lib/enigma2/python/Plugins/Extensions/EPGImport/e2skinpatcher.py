from __future__ import print_function

'''
SPDX-License-Identifier: GPL-2.0

Wrapper for DreamOS and all Enigma2 images
Prevents a green screen crash when using any unused methods or attributes in skin.xml on DreamOS
Compatible with Python 2.7, Python 3.12, and Python 3.13
Works on Dreambox 920, Vu+, OpenATV, VTI, OpenPLi, and all open source images
'''

import sys
import skin

# Detect Python version for compatibility
PY3 = sys.version_info[0] >= 3
isPython312 = sys.version_info[:2] => (3, 12)
isPython313 = sys.version_info[:2] => (3, 13)


class AttributeParser(object):
    def __init__(self, guiObject, desktop, scale=((1, 1), (1, 1))):
        self.guiObject = guiObject
        self.desktop = desktop
        self.scaleTuple = scale

    def applyOne(self, attrib, value):
        try:
            getattr(self, attrib)(value)
        except AttributeError:
            # Python 2.7 and Python 3.12/3.13 compatible string formatting
            print("[Skin_Patcher] Attribute '%s' (with value '%s') in object of type '%s' is not implemented!" %
                  (attrib, value, self.guiObject.__class__.__name__))
        except skin.SkinError as err:
            print("[Skin_Patcher] Error: %s" % str(err))
        except Exception:
            print("[Skin_Patcher] Attribute '%s' with wrong (or unknown) value '%s' in object of type '%s'!" %
                  (attrib, value, self.guiObject.__class__.__name__))

    def font(self, value):
        self.guiObject.setFont(skin.parseFont(value, self.scaleTuple))


def _applySingleAttribute(fn):
    def _fn(*args):
        # Ensure compatibility with different argument counts across Python versions and images
        try:
            guiObject, desktop, attrib, value, scale = args
        except ValueError:
            # Fallback for older/newer Enigma2 versions with different signatures
            if len(args) >= 5:
                guiObject, desktop, attrib, value, scale = args[:5]
            else:
                # Not enough arguments, call original function
                return fn(*args)
        if attrib == 'font':
            return AttributeParser(guiObject, desktop, scale).applyOne(attrib, value)
        else:
            return fn(*args)
    return _fn


try:
    # Apply patch for all images: DreamOS, OpenATV, VTI, OpenPLi, and open source
    # This prevents green screen crashes on unused skin attributes
    if hasattr(skin, 'applySingleAttribute'):
        skin.applySingleAttribute = _applySingleAttribute(skin.applySingleAttribute)
        print('[Skin_Patcher] Successfully patched skin.applySingleAttribute for Python %s' % ('3' if PY3 else '2'))
    else:
        print('[Skin_Patcher] Warning: skin.py has no applySingleAttribute (older image)')
except Exception as err:
    # Python 2.7 and Python 3.12/3.13 compatible error reporting
    print('[Skin_Patcher] Error: skin.py of the used image has no attribute "applySingleAttribute": %s' % repr(err))
